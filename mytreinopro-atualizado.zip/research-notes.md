# Pesquisa de nome e catálogo — notas de trabalho

## Nome e disponibilidade pública

A App Store Brasil apresenta como referências de apps de treino nomes como Freeletics, Desafio 30 Dias Para Fitness, Wakeout!, Down Dog, Seven, Asana Rebel, SmartGym, Sweat, Strava e Nike Run Club. Esses nomes devem ser evitados como inspiração direta para o novo nome.[1]

A base pePI do INPI é a fonte oficial para pesquisa pública de propriedade industrial e informa que a pesquisa pode ser feita anonimamente pelo botão “Continuar”, sem login obrigatório.[2] A investigação pública do nome será tratada como triagem, não como parecer jurídico ou garantia de disponibilidade para registro.

## Fontes abertas para catálogo de exercícios e equipamentos

As buscas localizaram referências de exercícios na MuscleWiki em português, no Hipertrofia.org e no GymPsycho, além de catálogos e guias de equipamentos da Life Fitness, MegaGym, D1Fitness, Supreme Fitness, Kikos e Tecnofit. Os resultados citam categorias como musculação, cardio, cross training, funcional, home gym, esteira, bicicleta, escada, remo, leg press, supino, puxada, Smith, peck deck, cadeira extensora, mesa/cadeira flexora, abdutora e adutora.[3]

## Referências consultadas

[1]: https://apps.apple.com/br/iphone/story/id1599761715 "Top 10 apps de exercícios — App Store Brasil"
[2]: https://busca.inpi.gov.br/pePI/ "pePI — Pesquisa em Propriedade Industrial — INPI"
[3]: https://www.lifefitness.com/pt-br/catalog "Catálogo de equipamentos — Life Fitness"
[4]: https://megagym.com.br/ "MegaGym Equipamentos Fitness"
[5]: https://d1fitness.com.br/ "D1Fitness"
[6]: https://supremeequipamentos.com.br/ "Supreme Fitness"
[7]: https://www.kikos.com.br/ "Kikos Fitness"
[8]: https://www.tecnofit.com.br/blog/nomes-dos-aparelhos-de-academia/ "Nomes dos aparelhos de academia — Tecnofit"
[9]: https://musclewiki.com/pt-br "MuscleWiki em português"
[10]: https://www.hipertrofia.org/blog/exercicios-de-musculacao/ "Exercícios de musculação — Hipertrofia.org"
[11]: https://gympsycho.com/pt/exercises/ "Catálogo de exercícios — GymPsycho"

## Achados adicionais

O guia da Tecnofit, atualizado em maio de 2026, organiza aparelhos por função e cita, entre outros, aparelho de glúteo, cadeiras abdutora/adutora/extensora/flexora, leg press, hack, barra guiada/Smith, elevação pélvica, panturrilha sentada, apolete, power cross e graviton.[8] A MuscleWiki mantém uma biblioteca pública de exercícios e links para seus aplicativos e API, servindo como referência de amplitude de movimentos, mas seus conteúdos não serão copiados literalmente sem avaliar licença.[9]

A amostra pública de nomes de apps fitness consultada não exibiu resultado diretamente associado a “Carga Nativa”, “Série Base” ou “Ritmo de Ferro” como app de registro de treinos. A opção provisória escolhida para o rebranding é **Carga Nativa**, por comunicar registro de carga e ter baixa colisão aparente na amostra. Isso não constitui garantia de disponibilidade no INPI, lojas, domínios ou redes sociais; a confirmação jurídica e a busca fonética oficial ainda devem ser feitas pelo titular antes de publicação comercial.
