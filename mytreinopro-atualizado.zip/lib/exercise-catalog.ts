// Base própria do MyTreinoPRO, organizada por grupo muscular e equipamento.
// Os nomes são descrições genéricas e não foram copiados de uma base proprietária.
export type ExerciseCatalogItem = {
  name: string;
  category: string;
  muscleGroup: string;
  equipment: string;
};

export const EXERCISE_CATALOG: ExerciseCatalogItem[] = [
  {
    "name": "Supino reto",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Barra"
  },
  {
    "name": "Supino reto — tradicional",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Barra"
  },
  {
    "name": "Supino reto — com pausa",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Barra"
  },
  {
    "name": "Supino reto — tempo controlado",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Barra"
  },
  {
    "name": "Supino reto — amplitude completa",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Barra"
  },
  {
    "name": "Supino reto — unilateral",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Barra"
  },
  {
    "name": "Supino reto — drop set",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Barra"
  },
  {
    "name": "Supino inclinado",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Barra"
  },
  {
    "name": "Supino inclinado — tradicional",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Barra"
  },
  {
    "name": "Supino inclinado — com pausa",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Barra"
  },
  {
    "name": "Supino inclinado — tempo controlado",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Barra"
  },
  {
    "name": "Supino inclinado — amplitude completa",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Barra"
  },
  {
    "name": "Supino inclinado — unilateral",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Barra"
  },
  {
    "name": "Supino inclinado — drop set",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Barra"
  },
  {
    "name": "Supino declinado",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Barra"
  },
  {
    "name": "Supino declinado — tradicional",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Barra"
  },
  {
    "name": "Supino declinado — com pausa",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Barra"
  },
  {
    "name": "Supino declinado — tempo controlado",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Barra"
  },
  {
    "name": "Supino declinado — amplitude completa",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Barra"
  },
  {
    "name": "Supino declinado — unilateral",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Barra"
  },
  {
    "name": "Supino declinado — drop set",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Barra"
  },
  {
    "name": "Supino reto",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Halter"
  },
  {
    "name": "Supino reto — tradicional",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Halter"
  },
  {
    "name": "Supino reto — com pausa",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Halter"
  },
  {
    "name": "Supino reto — tempo controlado",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Halter"
  },
  {
    "name": "Supino reto — amplitude completa",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Halter"
  },
  {
    "name": "Supino reto — unilateral",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Halter"
  },
  {
    "name": "Supino reto — drop set",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Halter"
  },
  {
    "name": "Supino inclinado",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Halter"
  },
  {
    "name": "Supino inclinado — tradicional",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Halter"
  },
  {
    "name": "Supino inclinado — com pausa",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Halter"
  },
  {
    "name": "Supino inclinado — tempo controlado",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Halter"
  },
  {
    "name": "Supino inclinado — amplitude completa",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Halter"
  },
  {
    "name": "Supino inclinado — unilateral",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Halter"
  },
  {
    "name": "Supino inclinado — drop set",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Halter"
  },
  {
    "name": "Supino declinado",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Halter"
  },
  {
    "name": "Supino declinado — tradicional",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Halter"
  },
  {
    "name": "Supino declinado — com pausa",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Halter"
  },
  {
    "name": "Supino declinado — tempo controlado",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Halter"
  },
  {
    "name": "Supino declinado — amplitude completa",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Halter"
  },
  {
    "name": "Supino declinado — unilateral",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Halter"
  },
  {
    "name": "Supino declinado — drop set",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Halter"
  },
  {
    "name": "Supino na máquina",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Máquina"
  },
  {
    "name": "Supino na máquina — tradicional",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Máquina"
  },
  {
    "name": "Supino na máquina — com pausa",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Máquina"
  },
  {
    "name": "Supino na máquina — tempo controlado",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Máquina"
  },
  {
    "name": "Supino na máquina — amplitude completa",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Máquina"
  },
  {
    "name": "Supino na máquina — unilateral",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Máquina"
  },
  {
    "name": "Supino na máquina — drop set",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Máquina"
  },
  {
    "name": "Chest press",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Máquina"
  },
  {
    "name": "Chest press — tradicional",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Máquina"
  },
  {
    "name": "Chest press — com pausa",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Máquina"
  },
  {
    "name": "Chest press — tempo controlado",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Máquina"
  },
  {
    "name": "Chest press — amplitude completa",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Máquina"
  },
  {
    "name": "Chest press — unilateral",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Máquina"
  },
  {
    "name": "Chest press — drop set",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Máquina"
  },
  {
    "name": "Crucifixo reto",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Halter"
  },
  {
    "name": "Crucifixo reto — tradicional",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Halter"
  },
  {
    "name": "Crucifixo reto — com pausa",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Halter"
  },
  {
    "name": "Crucifixo reto — tempo controlado",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Halter"
  },
  {
    "name": "Crucifixo reto — amplitude completa",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Halter"
  },
  {
    "name": "Crucifixo reto — unilateral",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Halter"
  },
  {
    "name": "Crucifixo reto — drop set",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Halter"
  },
  {
    "name": "Crucifixo inclinado",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Halter"
  },
  {
    "name": "Crucifixo inclinado — tradicional",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Halter"
  },
  {
    "name": "Crucifixo inclinado — com pausa",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Halter"
  },
  {
    "name": "Crucifixo inclinado — tempo controlado",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Halter"
  },
  {
    "name": "Crucifixo inclinado — amplitude completa",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Halter"
  },
  {
    "name": "Crucifixo inclinado — unilateral",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Halter"
  },
  {
    "name": "Crucifixo inclinado — drop set",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Halter"
  },
  {
    "name": "Crucifixo na máquina",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Máquina"
  },
  {
    "name": "Crucifixo na máquina — tradicional",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Máquina"
  },
  {
    "name": "Crucifixo na máquina — com pausa",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Máquina"
  },
  {
    "name": "Crucifixo na máquina — tempo controlado",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Máquina"
  },
  {
    "name": "Crucifixo na máquina — amplitude completa",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Máquina"
  },
  {
    "name": "Crucifixo na máquina — unilateral",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Máquina"
  },
  {
    "name": "Crucifixo na máquina — drop set",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Máquina"
  },
  {
    "name": "Crossover alto",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Polia"
  },
  {
    "name": "Crossover alto — tradicional",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Polia"
  },
  {
    "name": "Crossover alto — com pausa",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Polia"
  },
  {
    "name": "Crossover alto — tempo controlado",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Polia"
  },
  {
    "name": "Crossover alto — amplitude completa",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Polia"
  },
  {
    "name": "Crossover alto — unilateral",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Polia"
  },
  {
    "name": "Crossover alto — drop set",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Polia"
  },
  {
    "name": "Crossover médio",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Polia"
  },
  {
    "name": "Crossover médio — tradicional",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Polia"
  },
  {
    "name": "Crossover médio — com pausa",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Polia"
  },
  {
    "name": "Crossover médio — tempo controlado",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Polia"
  },
  {
    "name": "Crossover médio — amplitude completa",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Polia"
  },
  {
    "name": "Crossover médio — unilateral",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Polia"
  },
  {
    "name": "Crossover médio — drop set",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Polia"
  },
  {
    "name": "Crossover baixo",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Polia"
  },
  {
    "name": "Crossover baixo — tradicional",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Polia"
  },
  {
    "name": "Crossover baixo — com pausa",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Polia"
  },
  {
    "name": "Crossover baixo — tempo controlado",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Polia"
  },
  {
    "name": "Crossover baixo — amplitude completa",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Polia"
  },
  {
    "name": "Crossover baixo — unilateral",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Polia"
  },
  {
    "name": "Crossover baixo — drop set",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Polia"
  },
  {
    "name": "Flexão de braço",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Flexão de braço — tradicional",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Flexão de braço — com pausa",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Flexão de braço — tempo controlado",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Flexão de braço — amplitude completa",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Flexão de braço — unilateral",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Flexão de braço — drop set",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Flexão inclinada",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Flexão inclinada — tradicional",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Flexão inclinada — com pausa",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Flexão inclinada — tempo controlado",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Flexão inclinada — amplitude completa",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Flexão inclinada — unilateral",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Flexão inclinada — drop set",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Flexão declinada",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Flexão declinada — tradicional",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Flexão declinada — com pausa",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Flexão declinada — tempo controlado",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Flexão declinada — amplitude completa",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Flexão declinada — unilateral",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Flexão declinada — drop set",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Flexão diamante",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Flexão diamante — tradicional",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Flexão diamante — com pausa",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Flexão diamante — tempo controlado",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Flexão diamante — amplitude completa",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Flexão diamante — unilateral",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Flexão diamante — drop set",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Pullover",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Halter"
  },
  {
    "name": "Pullover — tradicional",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Halter"
  },
  {
    "name": "Pullover — com pausa",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Halter"
  },
  {
    "name": "Pullover — tempo controlado",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Halter"
  },
  {
    "name": "Pullover — amplitude completa",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Halter"
  },
  {
    "name": "Pullover — unilateral",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Halter"
  },
  {
    "name": "Pullover — drop set",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Halter"
  },
  {
    "name": "Pullover na polia",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Polia"
  },
  {
    "name": "Pullover na polia — tradicional",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Polia"
  },
  {
    "name": "Pullover na polia — com pausa",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Polia"
  },
  {
    "name": "Pullover na polia — tempo controlado",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Polia"
  },
  {
    "name": "Pullover na polia — amplitude completa",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Polia"
  },
  {
    "name": "Pullover na polia — unilateral",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Polia"
  },
  {
    "name": "Pullover na polia — drop set",
    "category": "Peito",
    "muscleGroup": "Peito",
    "equipment": "Polia"
  },
  {
    "name": "Puxada frontal",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Polia"
  },
  {
    "name": "Puxada frontal — tradicional",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Polia"
  },
  {
    "name": "Puxada frontal — com pausa",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Polia"
  },
  {
    "name": "Puxada frontal — tempo controlado",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Polia"
  },
  {
    "name": "Puxada frontal — amplitude completa",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Polia"
  },
  {
    "name": "Puxada frontal — unilateral",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Polia"
  },
  {
    "name": "Puxada frontal — drop set",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Polia"
  },
  {
    "name": "Puxada supinada",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Polia"
  },
  {
    "name": "Puxada supinada — tradicional",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Polia"
  },
  {
    "name": "Puxada supinada — com pausa",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Polia"
  },
  {
    "name": "Puxada supinada — tempo controlado",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Polia"
  },
  {
    "name": "Puxada supinada — amplitude completa",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Polia"
  },
  {
    "name": "Puxada supinada — unilateral",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Polia"
  },
  {
    "name": "Puxada supinada — drop set",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Polia"
  },
  {
    "name": "Puxada neutra",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Polia"
  },
  {
    "name": "Puxada neutra — tradicional",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Polia"
  },
  {
    "name": "Puxada neutra — com pausa",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Polia"
  },
  {
    "name": "Puxada neutra — tempo controlado",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Polia"
  },
  {
    "name": "Puxada neutra — amplitude completa",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Polia"
  },
  {
    "name": "Puxada neutra — unilateral",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Polia"
  },
  {
    "name": "Puxada neutra — drop set",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Polia"
  },
  {
    "name": "Puxada unilateral",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Polia"
  },
  {
    "name": "Puxada unilateral — tradicional",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Polia"
  },
  {
    "name": "Puxada unilateral — com pausa",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Polia"
  },
  {
    "name": "Puxada unilateral — tempo controlado",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Polia"
  },
  {
    "name": "Puxada unilateral — amplitude completa",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Polia"
  },
  {
    "name": "Puxada unilateral — unilateral",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Polia"
  },
  {
    "name": "Puxada unilateral — drop set",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Polia"
  },
  {
    "name": "Barra fixa pronada",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Barra fixa pronada — tradicional",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Barra fixa pronada — com pausa",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Barra fixa pronada — tempo controlado",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Barra fixa pronada — amplitude completa",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Barra fixa pronada — unilateral",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Barra fixa pronada — drop set",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Barra fixa supinada",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Barra fixa supinada — tradicional",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Barra fixa supinada — com pausa",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Barra fixa supinada — tempo controlado",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Barra fixa supinada — amplitude completa",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Barra fixa supinada — unilateral",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Barra fixa supinada — drop set",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Barra fixa neutra",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Barra fixa neutra — tradicional",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Barra fixa neutra — com pausa",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Barra fixa neutra — tempo controlado",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Barra fixa neutra — amplitude completa",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Barra fixa neutra — unilateral",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Barra fixa neutra — drop set",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Remada baixa",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Polia"
  },
  {
    "name": "Remada baixa — tradicional",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Polia"
  },
  {
    "name": "Remada baixa — com pausa",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Polia"
  },
  {
    "name": "Remada baixa — tempo controlado",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Polia"
  },
  {
    "name": "Remada baixa — amplitude completa",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Polia"
  },
  {
    "name": "Remada baixa — unilateral",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Polia"
  },
  {
    "name": "Remada baixa — drop set",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Polia"
  },
  {
    "name": "Remada curvada",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Barra"
  },
  {
    "name": "Remada curvada — tradicional",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Barra"
  },
  {
    "name": "Remada curvada — com pausa",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Barra"
  },
  {
    "name": "Remada curvada — tempo controlado",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Barra"
  },
  {
    "name": "Remada curvada — amplitude completa",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Barra"
  },
  {
    "name": "Remada curvada — unilateral",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Barra"
  },
  {
    "name": "Remada curvada — drop set",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Barra"
  },
  {
    "name": "Remada cavalinho",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Barra"
  },
  {
    "name": "Remada cavalinho — tradicional",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Barra"
  },
  {
    "name": "Remada cavalinho — com pausa",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Barra"
  },
  {
    "name": "Remada cavalinho — tempo controlado",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Barra"
  },
  {
    "name": "Remada cavalinho — amplitude completa",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Barra"
  },
  {
    "name": "Remada cavalinho — unilateral",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Barra"
  },
  {
    "name": "Remada cavalinho — drop set",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Barra"
  },
  {
    "name": "Remada unilateral",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Halter"
  },
  {
    "name": "Remada unilateral — tradicional",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Halter"
  },
  {
    "name": "Remada unilateral — com pausa",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Halter"
  },
  {
    "name": "Remada unilateral — tempo controlado",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Halter"
  },
  {
    "name": "Remada unilateral — amplitude completa",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Halter"
  },
  {
    "name": "Remada unilateral — unilateral",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Halter"
  },
  {
    "name": "Remada unilateral — drop set",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Halter"
  },
  {
    "name": "Remada na máquina",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Máquina"
  },
  {
    "name": "Remada na máquina — tradicional",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Máquina"
  },
  {
    "name": "Remada na máquina — com pausa",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Máquina"
  },
  {
    "name": "Remada na máquina — tempo controlado",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Máquina"
  },
  {
    "name": "Remada na máquina — amplitude completa",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Máquina"
  },
  {
    "name": "Remada na máquina — unilateral",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Máquina"
  },
  {
    "name": "Remada na máquina — drop set",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Máquina"
  },
  {
    "name": "Remada articulada",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Máquina"
  },
  {
    "name": "Remada articulada — tradicional",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Máquina"
  },
  {
    "name": "Remada articulada — com pausa",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Máquina"
  },
  {
    "name": "Remada articulada — tempo controlado",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Máquina"
  },
  {
    "name": "Remada articulada — amplitude completa",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Máquina"
  },
  {
    "name": "Remada articulada — unilateral",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Máquina"
  },
  {
    "name": "Remada articulada — drop set",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Máquina"
  },
  {
    "name": "Remada serrote",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Halter"
  },
  {
    "name": "Remada serrote — tradicional",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Halter"
  },
  {
    "name": "Remada serrote — com pausa",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Halter"
  },
  {
    "name": "Remada serrote — tempo controlado",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Halter"
  },
  {
    "name": "Remada serrote — amplitude completa",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Halter"
  },
  {
    "name": "Remada serrote — unilateral",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Halter"
  },
  {
    "name": "Remada serrote — drop set",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Halter"
  },
  {
    "name": "Pulldown reto",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Polia"
  },
  {
    "name": "Pulldown reto — tradicional",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Polia"
  },
  {
    "name": "Pulldown reto — com pausa",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Polia"
  },
  {
    "name": "Pulldown reto — tempo controlado",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Polia"
  },
  {
    "name": "Pulldown reto — amplitude completa",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Polia"
  },
  {
    "name": "Pulldown reto — unilateral",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Polia"
  },
  {
    "name": "Pulldown reto — drop set",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Polia"
  },
  {
    "name": "Pullover para dorsais",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Polia"
  },
  {
    "name": "Pullover para dorsais — tradicional",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Polia"
  },
  {
    "name": "Pullover para dorsais — com pausa",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Polia"
  },
  {
    "name": "Pullover para dorsais — tempo controlado",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Polia"
  },
  {
    "name": "Pullover para dorsais — amplitude completa",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Polia"
  },
  {
    "name": "Pullover para dorsais — unilateral",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Polia"
  },
  {
    "name": "Pullover para dorsais — drop set",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Polia"
  },
  {
    "name": "Encolhimento",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Halter"
  },
  {
    "name": "Encolhimento — tradicional",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Halter"
  },
  {
    "name": "Encolhimento — com pausa",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Halter"
  },
  {
    "name": "Encolhimento — tempo controlado",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Halter"
  },
  {
    "name": "Encolhimento — amplitude completa",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Halter"
  },
  {
    "name": "Encolhimento — unilateral",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Halter"
  },
  {
    "name": "Encolhimento — drop set",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Halter"
  },
  {
    "name": "Encolhimento com barra",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Barra"
  },
  {
    "name": "Encolhimento com barra — tradicional",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Barra"
  },
  {
    "name": "Encolhimento com barra — com pausa",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Barra"
  },
  {
    "name": "Encolhimento com barra — tempo controlado",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Barra"
  },
  {
    "name": "Encolhimento com barra — amplitude completa",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Barra"
  },
  {
    "name": "Encolhimento com barra — unilateral",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Barra"
  },
  {
    "name": "Encolhimento com barra — drop set",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Barra"
  },
  {
    "name": "Hiperextensão lombar",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Hiperextensão lombar — tradicional",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Hiperextensão lombar — com pausa",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Hiperextensão lombar — tempo controlado",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Hiperextensão lombar — amplitude completa",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Hiperextensão lombar — unilateral",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Hiperextensão lombar — drop set",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Good morning",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Barra"
  },
  {
    "name": "Good morning — tradicional",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Barra"
  },
  {
    "name": "Good morning — com pausa",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Barra"
  },
  {
    "name": "Good morning — tempo controlado",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Barra"
  },
  {
    "name": "Good morning — amplitude completa",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Barra"
  },
  {
    "name": "Good morning — unilateral",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Barra"
  },
  {
    "name": "Good morning — drop set",
    "category": "Costas",
    "muscleGroup": "Costas",
    "equipment": "Barra"
  },
  {
    "name": "Agachamento livre",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Barra"
  },
  {
    "name": "Agachamento livre — tradicional",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Barra"
  },
  {
    "name": "Agachamento livre — com pausa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Barra"
  },
  {
    "name": "Agachamento livre — tempo controlado",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Barra"
  },
  {
    "name": "Agachamento livre — amplitude completa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Barra"
  },
  {
    "name": "Agachamento livre — unilateral",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Barra"
  },
  {
    "name": "Agachamento livre — drop set",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Barra"
  },
  {
    "name": "Agachamento frontal",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Barra"
  },
  {
    "name": "Agachamento frontal — tradicional",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Barra"
  },
  {
    "name": "Agachamento frontal — com pausa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Barra"
  },
  {
    "name": "Agachamento frontal — tempo controlado",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Barra"
  },
  {
    "name": "Agachamento frontal — amplitude completa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Barra"
  },
  {
    "name": "Agachamento frontal — unilateral",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Barra"
  },
  {
    "name": "Agachamento frontal — drop set",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Barra"
  },
  {
    "name": "Agachamento sumô",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Agachamento sumô — tradicional",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Agachamento sumô — com pausa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Agachamento sumô — tempo controlado",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Agachamento sumô — amplitude completa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Agachamento sumô — unilateral",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Agachamento sumô — drop set",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Agachamento goblet",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Kettlebell"
  },
  {
    "name": "Agachamento goblet — tradicional",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Kettlebell"
  },
  {
    "name": "Agachamento goblet — com pausa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Kettlebell"
  },
  {
    "name": "Agachamento goblet — tempo controlado",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Kettlebell"
  },
  {
    "name": "Agachamento goblet — amplitude completa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Kettlebell"
  },
  {
    "name": "Agachamento goblet — unilateral",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Kettlebell"
  },
  {
    "name": "Agachamento goblet — drop set",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Kettlebell"
  },
  {
    "name": "Agachamento no Smith",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Agachamento no Smith — tradicional",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Agachamento no Smith — com pausa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Agachamento no Smith — tempo controlado",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Agachamento no Smith — amplitude completa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Agachamento no Smith — unilateral",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Agachamento no Smith — drop set",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Agachamento hack",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Agachamento hack — tradicional",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Agachamento hack — com pausa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Agachamento hack — tempo controlado",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Agachamento hack — amplitude completa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Agachamento hack — unilateral",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Agachamento hack — drop set",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Leg press 45°",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Leg press 45° — tradicional",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Leg press 45° — com pausa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Leg press 45° — tempo controlado",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Leg press 45° — amplitude completa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Leg press 45° — unilateral",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Leg press 45° — drop set",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Leg press horizontal",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Leg press horizontal — tradicional",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Leg press horizontal — com pausa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Leg press horizontal — tempo controlado",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Leg press horizontal — amplitude completa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Leg press horizontal — unilateral",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Leg press horizontal — drop set",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Cadeira extensora",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Cadeira extensora — tradicional",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Cadeira extensora — com pausa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Cadeira extensora — tempo controlado",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Cadeira extensora — amplitude completa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Cadeira extensora — unilateral",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Cadeira extensora — drop set",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Cadeira flexora",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Cadeira flexora — tradicional",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Cadeira flexora — com pausa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Cadeira flexora — tempo controlado",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Cadeira flexora — amplitude completa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Cadeira flexora — unilateral",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Cadeira flexora — drop set",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Mesa flexora",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Mesa flexora — tradicional",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Mesa flexora — com pausa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Mesa flexora — tempo controlado",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Mesa flexora — amplitude completa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Mesa flexora — unilateral",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Mesa flexora — drop set",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Levantamento terra",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Barra"
  },
  {
    "name": "Levantamento terra — tradicional",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Barra"
  },
  {
    "name": "Levantamento terra — com pausa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Barra"
  },
  {
    "name": "Levantamento terra — tempo controlado",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Barra"
  },
  {
    "name": "Levantamento terra — amplitude completa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Barra"
  },
  {
    "name": "Levantamento terra — unilateral",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Barra"
  },
  {
    "name": "Levantamento terra — drop set",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Barra"
  },
  {
    "name": "Terra romeno",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Barra"
  },
  {
    "name": "Terra romeno — tradicional",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Barra"
  },
  {
    "name": "Terra romeno — com pausa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Barra"
  },
  {
    "name": "Terra romeno — tempo controlado",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Barra"
  },
  {
    "name": "Terra romeno — amplitude completa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Barra"
  },
  {
    "name": "Terra romeno — unilateral",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Barra"
  },
  {
    "name": "Terra romeno — drop set",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Barra"
  },
  {
    "name": "Terra sumô",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Barra"
  },
  {
    "name": "Terra sumô — tradicional",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Barra"
  },
  {
    "name": "Terra sumô — com pausa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Barra"
  },
  {
    "name": "Terra sumô — tempo controlado",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Barra"
  },
  {
    "name": "Terra sumô — amplitude completa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Barra"
  },
  {
    "name": "Terra sumô — unilateral",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Barra"
  },
  {
    "name": "Terra sumô — drop set",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Barra"
  },
  {
    "name": "Stiff",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Barra"
  },
  {
    "name": "Stiff — tradicional",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Barra"
  },
  {
    "name": "Stiff — com pausa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Barra"
  },
  {
    "name": "Stiff — tempo controlado",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Barra"
  },
  {
    "name": "Stiff — amplitude completa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Barra"
  },
  {
    "name": "Stiff — unilateral",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Barra"
  },
  {
    "name": "Stiff — drop set",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Barra"
  },
  {
    "name": "Stiff unilateral",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Stiff unilateral — tradicional",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Stiff unilateral — com pausa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Stiff unilateral — tempo controlado",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Stiff unilateral — amplitude completa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Stiff unilateral — unilateral",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Stiff unilateral — drop set",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Afundo",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Afundo — tradicional",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Afundo — com pausa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Afundo — tempo controlado",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Afundo — amplitude completa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Afundo — unilateral",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Afundo — drop set",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Afundo no Smith",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Afundo no Smith — tradicional",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Afundo no Smith — com pausa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Afundo no Smith — tempo controlado",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Afundo no Smith — amplitude completa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Afundo no Smith — unilateral",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Afundo no Smith — drop set",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Passada",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Passada — tradicional",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Passada — com pausa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Passada — tempo controlado",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Passada — amplitude completa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Passada — unilateral",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Passada — drop set",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Passada reversa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Passada reversa — tradicional",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Passada reversa — com pausa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Passada reversa — tempo controlado",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Passada reversa — amplitude completa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Passada reversa — unilateral",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Passada reversa — drop set",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Passada caminhando",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Passada caminhando — tradicional",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Passada caminhando — com pausa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Passada caminhando — tempo controlado",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Passada caminhando — amplitude completa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Passada caminhando — unilateral",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Passada caminhando — drop set",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Step-up",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Step-up — tradicional",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Step-up — com pausa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Step-up — tempo controlado",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Step-up — amplitude completa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Step-up — unilateral",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Step-up — drop set",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Step-up",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Step-up — tradicional",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Step-up — com pausa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Step-up — tempo controlado",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Step-up — amplitude completa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Step-up — unilateral",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Step-up — drop set",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Agachamento búlgaro",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Agachamento búlgaro — tradicional",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Agachamento búlgaro — com pausa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Agachamento búlgaro — tempo controlado",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Agachamento búlgaro — amplitude completa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Agachamento búlgaro — unilateral",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Agachamento búlgaro — drop set",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Halter"
  },
  {
    "name": "Cadeira sissy",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Cadeira sissy — tradicional",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Cadeira sissy — com pausa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Cadeira sissy — tempo controlado",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Cadeira sissy — amplitude completa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Cadeira sissy — unilateral",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Cadeira sissy — drop set",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Flexão nórdica",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Flexão nórdica — tradicional",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Flexão nórdica — com pausa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Flexão nórdica — tempo controlado",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Flexão nórdica — amplitude completa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Flexão nórdica — unilateral",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Flexão nórdica — drop set",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Extensão de quadril",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Polia"
  },
  {
    "name": "Extensão de quadril — tradicional",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Polia"
  },
  {
    "name": "Extensão de quadril — com pausa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Polia"
  },
  {
    "name": "Extensão de quadril — tempo controlado",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Polia"
  },
  {
    "name": "Extensão de quadril — amplitude completa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Polia"
  },
  {
    "name": "Extensão de quadril — unilateral",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Polia"
  },
  {
    "name": "Extensão de quadril — drop set",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Polia"
  },
  {
    "name": "Adutora",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Adutora — tradicional",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Adutora — com pausa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Adutora — tempo controlado",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Adutora — amplitude completa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Adutora — unilateral",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Adutora — drop set",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Abdutora",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Abdutora — tradicional",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Abdutora — com pausa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Abdutora — tempo controlado",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Abdutora — amplitude completa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Abdutora — unilateral",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Abdutora — drop set",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Máquina"
  },
  {
    "name": "Agachamento com elástico",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Elástico"
  },
  {
    "name": "Agachamento com elástico — tradicional",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Elástico"
  },
  {
    "name": "Agachamento com elástico — com pausa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Elástico"
  },
  {
    "name": "Agachamento com elástico — tempo controlado",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Elástico"
  },
  {
    "name": "Agachamento com elástico — amplitude completa",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Elástico"
  },
  {
    "name": "Agachamento com elástico — unilateral",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Elástico"
  },
  {
    "name": "Agachamento com elástico — drop set",
    "category": "Pernas",
    "muscleGroup": "Pernas",
    "equipment": "Elástico"
  },
  {
    "name": "Elevação pélvica",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Barra"
  },
  {
    "name": "Elevação pélvica — tradicional",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Barra"
  },
  {
    "name": "Elevação pélvica — com pausa",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Barra"
  },
  {
    "name": "Elevação pélvica — tempo controlado",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Barra"
  },
  {
    "name": "Elevação pélvica — amplitude completa",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Barra"
  },
  {
    "name": "Elevação pélvica — unilateral",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Barra"
  },
  {
    "name": "Elevação pélvica — drop set",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Barra"
  },
  {
    "name": "Elevação pélvica",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Máquina"
  },
  {
    "name": "Elevação pélvica — tradicional",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Máquina"
  },
  {
    "name": "Elevação pélvica — com pausa",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Máquina"
  },
  {
    "name": "Elevação pélvica — tempo controlado",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Máquina"
  },
  {
    "name": "Elevação pélvica — amplitude completa",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Máquina"
  },
  {
    "name": "Elevação pélvica — unilateral",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Máquina"
  },
  {
    "name": "Elevação pélvica — drop set",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Máquina"
  },
  {
    "name": "Elevação pélvica unilateral",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Elevação pélvica unilateral — tradicional",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Elevação pélvica unilateral — com pausa",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Elevação pélvica unilateral — tempo controlado",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Elevação pélvica unilateral — amplitude completa",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Elevação pélvica unilateral — unilateral",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Elevação pélvica unilateral — drop set",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Glúteo no cabo",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Polia"
  },
  {
    "name": "Glúteo no cabo — tradicional",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Polia"
  },
  {
    "name": "Glúteo no cabo — com pausa",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Polia"
  },
  {
    "name": "Glúteo no cabo — tempo controlado",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Polia"
  },
  {
    "name": "Glúteo no cabo — amplitude completa",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Polia"
  },
  {
    "name": "Glúteo no cabo — unilateral",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Polia"
  },
  {
    "name": "Glúteo no cabo — drop set",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Polia"
  },
  {
    "name": "Glúteo na máquina",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Máquina"
  },
  {
    "name": "Glúteo na máquina — tradicional",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Máquina"
  },
  {
    "name": "Glúteo na máquina — com pausa",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Máquina"
  },
  {
    "name": "Glúteo na máquina — tempo controlado",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Máquina"
  },
  {
    "name": "Glúteo na máquina — amplitude completa",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Máquina"
  },
  {
    "name": "Glúteo na máquina — unilateral",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Máquina"
  },
  {
    "name": "Glúteo na máquina — drop set",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Máquina"
  },
  {
    "name": "Coice no cabo",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Polia"
  },
  {
    "name": "Coice no cabo — tradicional",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Polia"
  },
  {
    "name": "Coice no cabo — com pausa",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Polia"
  },
  {
    "name": "Coice no cabo — tempo controlado",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Polia"
  },
  {
    "name": "Coice no cabo — amplitude completa",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Polia"
  },
  {
    "name": "Coice no cabo — unilateral",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Polia"
  },
  {
    "name": "Coice no cabo — drop set",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Polia"
  },
  {
    "name": "Coice com elástico",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Elástico"
  },
  {
    "name": "Coice com elástico — tradicional",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Elástico"
  },
  {
    "name": "Coice com elástico — com pausa",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Elástico"
  },
  {
    "name": "Coice com elástico — tempo controlado",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Elástico"
  },
  {
    "name": "Coice com elástico — amplitude completa",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Elástico"
  },
  {
    "name": "Coice com elástico — unilateral",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Elástico"
  },
  {
    "name": "Coice com elástico — drop set",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Elástico"
  },
  {
    "name": "Abdução de quadril",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Máquina"
  },
  {
    "name": "Abdução de quadril — tradicional",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Máquina"
  },
  {
    "name": "Abdução de quadril — com pausa",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Máquina"
  },
  {
    "name": "Abdução de quadril — tempo controlado",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Máquina"
  },
  {
    "name": "Abdução de quadril — amplitude completa",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Máquina"
  },
  {
    "name": "Abdução de quadril — unilateral",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Máquina"
  },
  {
    "name": "Abdução de quadril — drop set",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Máquina"
  },
  {
    "name": "Abdução de quadril",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Elástico"
  },
  {
    "name": "Abdução de quadril — tradicional",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Elástico"
  },
  {
    "name": "Abdução de quadril — com pausa",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Elástico"
  },
  {
    "name": "Abdução de quadril — tempo controlado",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Elástico"
  },
  {
    "name": "Abdução de quadril — amplitude completa",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Elástico"
  },
  {
    "name": "Abdução de quadril — unilateral",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Elástico"
  },
  {
    "name": "Abdução de quadril — drop set",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Elástico"
  },
  {
    "name": "Extensão de quadril",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Banco"
  },
  {
    "name": "Extensão de quadril — tradicional",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Banco"
  },
  {
    "name": "Extensão de quadril — com pausa",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Banco"
  },
  {
    "name": "Extensão de quadril — tempo controlado",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Banco"
  },
  {
    "name": "Extensão de quadril — amplitude completa",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Banco"
  },
  {
    "name": "Extensão de quadril — unilateral",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Banco"
  },
  {
    "name": "Extensão de quadril — drop set",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Banco"
  },
  {
    "name": "Frog pump",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Frog pump — tradicional",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Frog pump — com pausa",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Frog pump — tempo controlado",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Frog pump — amplitude completa",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Frog pump — unilateral",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Frog pump — drop set",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Bom dia",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Barra"
  },
  {
    "name": "Bom dia — tradicional",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Barra"
  },
  {
    "name": "Bom dia — com pausa",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Barra"
  },
  {
    "name": "Bom dia — tempo controlado",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Barra"
  },
  {
    "name": "Bom dia — amplitude completa",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Barra"
  },
  {
    "name": "Bom dia — unilateral",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Barra"
  },
  {
    "name": "Bom dia — drop set",
    "category": "Glúteos",
    "muscleGroup": "Glúteos",
    "equipment": "Barra"
  },
  {
    "name": "Desenvolvimento militar",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Barra"
  },
  {
    "name": "Desenvolvimento militar — tradicional",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Barra"
  },
  {
    "name": "Desenvolvimento militar — com pausa",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Barra"
  },
  {
    "name": "Desenvolvimento militar — tempo controlado",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Barra"
  },
  {
    "name": "Desenvolvimento militar — amplitude completa",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Barra"
  },
  {
    "name": "Desenvolvimento militar — unilateral",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Barra"
  },
  {
    "name": "Desenvolvimento militar — drop set",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Barra"
  },
  {
    "name": "Desenvolvimento com halteres",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Halter"
  },
  {
    "name": "Desenvolvimento com halteres — tradicional",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Halter"
  },
  {
    "name": "Desenvolvimento com halteres — com pausa",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Halter"
  },
  {
    "name": "Desenvolvimento com halteres — tempo controlado",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Halter"
  },
  {
    "name": "Desenvolvimento com halteres — amplitude completa",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Halter"
  },
  {
    "name": "Desenvolvimento com halteres — unilateral",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Halter"
  },
  {
    "name": "Desenvolvimento com halteres — drop set",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Halter"
  },
  {
    "name": "Desenvolvimento Arnold",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Halter"
  },
  {
    "name": "Desenvolvimento Arnold — tradicional",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Halter"
  },
  {
    "name": "Desenvolvimento Arnold — com pausa",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Halter"
  },
  {
    "name": "Desenvolvimento Arnold — tempo controlado",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Halter"
  },
  {
    "name": "Desenvolvimento Arnold — amplitude completa",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Halter"
  },
  {
    "name": "Desenvolvimento Arnold — unilateral",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Halter"
  },
  {
    "name": "Desenvolvimento Arnold — drop set",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Halter"
  },
  {
    "name": "Desenvolvimento no Smith",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Máquina"
  },
  {
    "name": "Desenvolvimento no Smith — tradicional",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Máquina"
  },
  {
    "name": "Desenvolvimento no Smith — com pausa",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Máquina"
  },
  {
    "name": "Desenvolvimento no Smith — tempo controlado",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Máquina"
  },
  {
    "name": "Desenvolvimento no Smith — amplitude completa",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Máquina"
  },
  {
    "name": "Desenvolvimento no Smith — unilateral",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Máquina"
  },
  {
    "name": "Desenvolvimento no Smith — drop set",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Máquina"
  },
  {
    "name": "Desenvolvimento na máquina",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Máquina"
  },
  {
    "name": "Desenvolvimento na máquina — tradicional",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Máquina"
  },
  {
    "name": "Desenvolvimento na máquina — com pausa",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Máquina"
  },
  {
    "name": "Desenvolvimento na máquina — tempo controlado",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Máquina"
  },
  {
    "name": "Desenvolvimento na máquina — amplitude completa",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Máquina"
  },
  {
    "name": "Desenvolvimento na máquina — unilateral",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Máquina"
  },
  {
    "name": "Desenvolvimento na máquina — drop set",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Máquina"
  },
  {
    "name": "Elevação lateral",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Halter"
  },
  {
    "name": "Elevação lateral — tradicional",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Halter"
  },
  {
    "name": "Elevação lateral — com pausa",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Halter"
  },
  {
    "name": "Elevação lateral — tempo controlado",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Halter"
  },
  {
    "name": "Elevação lateral — amplitude completa",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Halter"
  },
  {
    "name": "Elevação lateral — unilateral",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Halter"
  },
  {
    "name": "Elevação lateral — drop set",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Halter"
  },
  {
    "name": "Elevação lateral na polia",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Polia"
  },
  {
    "name": "Elevação lateral na polia — tradicional",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Polia"
  },
  {
    "name": "Elevação lateral na polia — com pausa",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Polia"
  },
  {
    "name": "Elevação lateral na polia — tempo controlado",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Polia"
  },
  {
    "name": "Elevação lateral na polia — amplitude completa",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Polia"
  },
  {
    "name": "Elevação lateral na polia — unilateral",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Polia"
  },
  {
    "name": "Elevação lateral na polia — drop set",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Polia"
  },
  {
    "name": "Elevação lateral na máquina",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Máquina"
  },
  {
    "name": "Elevação lateral na máquina — tradicional",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Máquina"
  },
  {
    "name": "Elevação lateral na máquina — com pausa",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Máquina"
  },
  {
    "name": "Elevação lateral na máquina — tempo controlado",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Máquina"
  },
  {
    "name": "Elevação lateral na máquina — amplitude completa",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Máquina"
  },
  {
    "name": "Elevação lateral na máquina — unilateral",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Máquina"
  },
  {
    "name": "Elevação lateral na máquina — drop set",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Máquina"
  },
  {
    "name": "Elevação frontal",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Halter"
  },
  {
    "name": "Elevação frontal — tradicional",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Halter"
  },
  {
    "name": "Elevação frontal — com pausa",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Halter"
  },
  {
    "name": "Elevação frontal — tempo controlado",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Halter"
  },
  {
    "name": "Elevação frontal — amplitude completa",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Halter"
  },
  {
    "name": "Elevação frontal — unilateral",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Halter"
  },
  {
    "name": "Elevação frontal — drop set",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Halter"
  },
  {
    "name": "Elevação frontal com barra",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Barra"
  },
  {
    "name": "Elevação frontal com barra — tradicional",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Barra"
  },
  {
    "name": "Elevação frontal com barra — com pausa",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Barra"
  },
  {
    "name": "Elevação frontal com barra — tempo controlado",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Barra"
  },
  {
    "name": "Elevação frontal com barra — amplitude completa",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Barra"
  },
  {
    "name": "Elevação frontal com barra — unilateral",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Barra"
  },
  {
    "name": "Elevação frontal com barra — drop set",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Barra"
  },
  {
    "name": "Elevação frontal na polia",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Polia"
  },
  {
    "name": "Elevação frontal na polia — tradicional",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Polia"
  },
  {
    "name": "Elevação frontal na polia — com pausa",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Polia"
  },
  {
    "name": "Elevação frontal na polia — tempo controlado",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Polia"
  },
  {
    "name": "Elevação frontal na polia — amplitude completa",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Polia"
  },
  {
    "name": "Elevação frontal na polia — unilateral",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Polia"
  },
  {
    "name": "Elevação frontal na polia — drop set",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Polia"
  },
  {
    "name": "Crucifixo inverso",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Halter"
  },
  {
    "name": "Crucifixo inverso — tradicional",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Halter"
  },
  {
    "name": "Crucifixo inverso — com pausa",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Halter"
  },
  {
    "name": "Crucifixo inverso — tempo controlado",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Halter"
  },
  {
    "name": "Crucifixo inverso — amplitude completa",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Halter"
  },
  {
    "name": "Crucifixo inverso — unilateral",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Halter"
  },
  {
    "name": "Crucifixo inverso — drop set",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Halter"
  },
  {
    "name": "Crucifixo inverso na máquina",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Máquina"
  },
  {
    "name": "Crucifixo inverso na máquina — tradicional",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Máquina"
  },
  {
    "name": "Crucifixo inverso na máquina — com pausa",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Máquina"
  },
  {
    "name": "Crucifixo inverso na máquina — tempo controlado",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Máquina"
  },
  {
    "name": "Crucifixo inverso na máquina — amplitude completa",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Máquina"
  },
  {
    "name": "Crucifixo inverso na máquina — unilateral",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Máquina"
  },
  {
    "name": "Crucifixo inverso na máquina — drop set",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Máquina"
  },
  {
    "name": "Face pull",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Polia"
  },
  {
    "name": "Face pull — tradicional",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Polia"
  },
  {
    "name": "Face pull — com pausa",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Polia"
  },
  {
    "name": "Face pull — tempo controlado",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Polia"
  },
  {
    "name": "Face pull — amplitude completa",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Polia"
  },
  {
    "name": "Face pull — unilateral",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Polia"
  },
  {
    "name": "Face pull — drop set",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Polia"
  },
  {
    "name": "Remada alta",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Barra"
  },
  {
    "name": "Remada alta — tradicional",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Barra"
  },
  {
    "name": "Remada alta — com pausa",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Barra"
  },
  {
    "name": "Remada alta — tempo controlado",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Barra"
  },
  {
    "name": "Remada alta — amplitude completa",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Barra"
  },
  {
    "name": "Remada alta — unilateral",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Barra"
  },
  {
    "name": "Remada alta — drop set",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Barra"
  },
  {
    "name": "Remada alta na polia",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Polia"
  },
  {
    "name": "Remada alta na polia — tradicional",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Polia"
  },
  {
    "name": "Remada alta na polia — com pausa",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Polia"
  },
  {
    "name": "Remada alta na polia — tempo controlado",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Polia"
  },
  {
    "name": "Remada alta na polia — amplitude completa",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Polia"
  },
  {
    "name": "Remada alta na polia — unilateral",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Polia"
  },
  {
    "name": "Remada alta na polia — drop set",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Polia"
  },
  {
    "name": "Rotação externa",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Elástico"
  },
  {
    "name": "Rotação externa — tradicional",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Elástico"
  },
  {
    "name": "Rotação externa — com pausa",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Elástico"
  },
  {
    "name": "Rotação externa — tempo controlado",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Elástico"
  },
  {
    "name": "Rotação externa — amplitude completa",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Elástico"
  },
  {
    "name": "Rotação externa — unilateral",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Elástico"
  },
  {
    "name": "Rotação externa — drop set",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Elástico"
  },
  {
    "name": "Rotação interna",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Elástico"
  },
  {
    "name": "Rotação interna — tradicional",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Elástico"
  },
  {
    "name": "Rotação interna — com pausa",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Elástico"
  },
  {
    "name": "Rotação interna — tempo controlado",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Elástico"
  },
  {
    "name": "Rotação interna — amplitude completa",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Elástico"
  },
  {
    "name": "Rotação interna — unilateral",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Elástico"
  },
  {
    "name": "Rotação interna — drop set",
    "category": "Ombros",
    "muscleGroup": "Ombros",
    "equipment": "Elástico"
  },
  {
    "name": "Rosca direta",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Barra"
  },
  {
    "name": "Rosca direta — tradicional",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Barra"
  },
  {
    "name": "Rosca direta — com pausa",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Barra"
  },
  {
    "name": "Rosca direta — tempo controlado",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Barra"
  },
  {
    "name": "Rosca direta — amplitude completa",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Barra"
  },
  {
    "name": "Rosca direta — unilateral",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Barra"
  },
  {
    "name": "Rosca direta — drop set",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Barra"
  },
  {
    "name": "Rosca direta na polia",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Polia"
  },
  {
    "name": "Rosca direta na polia — tradicional",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Polia"
  },
  {
    "name": "Rosca direta na polia — com pausa",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Polia"
  },
  {
    "name": "Rosca direta na polia — tempo controlado",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Polia"
  },
  {
    "name": "Rosca direta na polia — amplitude completa",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Polia"
  },
  {
    "name": "Rosca direta na polia — unilateral",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Polia"
  },
  {
    "name": "Rosca direta na polia — drop set",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Polia"
  },
  {
    "name": "Rosca W",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Barra"
  },
  {
    "name": "Rosca W — tradicional",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Barra"
  },
  {
    "name": "Rosca W — com pausa",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Barra"
  },
  {
    "name": "Rosca W — tempo controlado",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Barra"
  },
  {
    "name": "Rosca W — amplitude completa",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Barra"
  },
  {
    "name": "Rosca W — unilateral",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Barra"
  },
  {
    "name": "Rosca W — drop set",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Barra"
  },
  {
    "name": "Rosca Scott",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Barra"
  },
  {
    "name": "Rosca Scott — tradicional",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Barra"
  },
  {
    "name": "Rosca Scott — com pausa",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Barra"
  },
  {
    "name": "Rosca Scott — tempo controlado",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Barra"
  },
  {
    "name": "Rosca Scott — amplitude completa",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Barra"
  },
  {
    "name": "Rosca Scott — unilateral",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Barra"
  },
  {
    "name": "Rosca Scott — drop set",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Barra"
  },
  {
    "name": "Rosca Scott na máquina",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Máquina"
  },
  {
    "name": "Rosca Scott na máquina — tradicional",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Máquina"
  },
  {
    "name": "Rosca Scott na máquina — com pausa",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Máquina"
  },
  {
    "name": "Rosca Scott na máquina — tempo controlado",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Máquina"
  },
  {
    "name": "Rosca Scott na máquina — amplitude completa",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Máquina"
  },
  {
    "name": "Rosca Scott na máquina — unilateral",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Máquina"
  },
  {
    "name": "Rosca Scott na máquina — drop set",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Máquina"
  },
  {
    "name": "Rosca alternada",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Halter"
  },
  {
    "name": "Rosca alternada — tradicional",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Halter"
  },
  {
    "name": "Rosca alternada — com pausa",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Halter"
  },
  {
    "name": "Rosca alternada — tempo controlado",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Halter"
  },
  {
    "name": "Rosca alternada — amplitude completa",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Halter"
  },
  {
    "name": "Rosca alternada — unilateral",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Halter"
  },
  {
    "name": "Rosca alternada — drop set",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Halter"
  },
  {
    "name": "Rosca simultânea",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Halter"
  },
  {
    "name": "Rosca simultânea — tradicional",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Halter"
  },
  {
    "name": "Rosca simultânea — com pausa",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Halter"
  },
  {
    "name": "Rosca simultânea — tempo controlado",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Halter"
  },
  {
    "name": "Rosca simultânea — amplitude completa",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Halter"
  },
  {
    "name": "Rosca simultânea — unilateral",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Halter"
  },
  {
    "name": "Rosca simultânea — drop set",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Halter"
  },
  {
    "name": "Rosca martelo",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Halter"
  },
  {
    "name": "Rosca martelo — tradicional",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Halter"
  },
  {
    "name": "Rosca martelo — com pausa",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Halter"
  },
  {
    "name": "Rosca martelo — tempo controlado",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Halter"
  },
  {
    "name": "Rosca martelo — amplitude completa",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Halter"
  },
  {
    "name": "Rosca martelo — unilateral",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Halter"
  },
  {
    "name": "Rosca martelo — drop set",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Halter"
  },
  {
    "name": "Rosca martelo na corda",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Polia"
  },
  {
    "name": "Rosca martelo na corda — tradicional",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Polia"
  },
  {
    "name": "Rosca martelo na corda — com pausa",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Polia"
  },
  {
    "name": "Rosca martelo na corda — tempo controlado",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Polia"
  },
  {
    "name": "Rosca martelo na corda — amplitude completa",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Polia"
  },
  {
    "name": "Rosca martelo na corda — unilateral",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Polia"
  },
  {
    "name": "Rosca martelo na corda — drop set",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Polia"
  },
  {
    "name": "Rosca concentrada",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Halter"
  },
  {
    "name": "Rosca concentrada — tradicional",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Halter"
  },
  {
    "name": "Rosca concentrada — com pausa",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Halter"
  },
  {
    "name": "Rosca concentrada — tempo controlado",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Halter"
  },
  {
    "name": "Rosca concentrada — amplitude completa",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Halter"
  },
  {
    "name": "Rosca concentrada — unilateral",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Halter"
  },
  {
    "name": "Rosca concentrada — drop set",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Halter"
  },
  {
    "name": "Rosca inclinada",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Halter"
  },
  {
    "name": "Rosca inclinada — tradicional",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Halter"
  },
  {
    "name": "Rosca inclinada — com pausa",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Halter"
  },
  {
    "name": "Rosca inclinada — tempo controlado",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Halter"
  },
  {
    "name": "Rosca inclinada — amplitude completa",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Halter"
  },
  {
    "name": "Rosca inclinada — unilateral",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Halter"
  },
  {
    "name": "Rosca inclinada — drop set",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Halter"
  },
  {
    "name": "Rosca spider",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Halter"
  },
  {
    "name": "Rosca spider — tradicional",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Halter"
  },
  {
    "name": "Rosca spider — com pausa",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Halter"
  },
  {
    "name": "Rosca spider — tempo controlado",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Halter"
  },
  {
    "name": "Rosca spider — amplitude completa",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Halter"
  },
  {
    "name": "Rosca spider — unilateral",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Halter"
  },
  {
    "name": "Rosca spider — drop set",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Halter"
  },
  {
    "name": "Rosca inversa",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Barra"
  },
  {
    "name": "Rosca inversa — tradicional",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Barra"
  },
  {
    "name": "Rosca inversa — com pausa",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Barra"
  },
  {
    "name": "Rosca inversa — tempo controlado",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Barra"
  },
  {
    "name": "Rosca inversa — amplitude completa",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Barra"
  },
  {
    "name": "Rosca inversa — unilateral",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Barra"
  },
  {
    "name": "Rosca inversa — drop set",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Barra"
  },
  {
    "name": "Rosca drag",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Barra"
  },
  {
    "name": "Rosca drag — tradicional",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Barra"
  },
  {
    "name": "Rosca drag — com pausa",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Barra"
  },
  {
    "name": "Rosca drag — tempo controlado",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Barra"
  },
  {
    "name": "Rosca drag — amplitude completa",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Barra"
  },
  {
    "name": "Rosca drag — unilateral",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Barra"
  },
  {
    "name": "Rosca drag — drop set",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Barra"
  },
  {
    "name": "Rosca 21",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Barra"
  },
  {
    "name": "Rosca 21 — tradicional",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Barra"
  },
  {
    "name": "Rosca 21 — com pausa",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Barra"
  },
  {
    "name": "Rosca 21 — tempo controlado",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Barra"
  },
  {
    "name": "Rosca 21 — amplitude completa",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Barra"
  },
  {
    "name": "Rosca 21 — unilateral",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Barra"
  },
  {
    "name": "Rosca 21 — drop set",
    "category": "Bíceps",
    "muscleGroup": "Bíceps",
    "equipment": "Barra"
  },
  {
    "name": "Tríceps na polia",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Polia"
  },
  {
    "name": "Tríceps na polia — tradicional",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Polia"
  },
  {
    "name": "Tríceps na polia — com pausa",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Polia"
  },
  {
    "name": "Tríceps na polia — tempo controlado",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Polia"
  },
  {
    "name": "Tríceps na polia — amplitude completa",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Polia"
  },
  {
    "name": "Tríceps na polia — unilateral",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Polia"
  },
  {
    "name": "Tríceps na polia — drop set",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Polia"
  },
  {
    "name": "Tríceps na corda",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Polia"
  },
  {
    "name": "Tríceps na corda — tradicional",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Polia"
  },
  {
    "name": "Tríceps na corda — com pausa",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Polia"
  },
  {
    "name": "Tríceps na corda — tempo controlado",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Polia"
  },
  {
    "name": "Tríceps na corda — amplitude completa",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Polia"
  },
  {
    "name": "Tríceps na corda — unilateral",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Polia"
  },
  {
    "name": "Tríceps na corda — drop set",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Polia"
  },
  {
    "name": "Tríceps barra reta",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Polia"
  },
  {
    "name": "Tríceps barra reta — tradicional",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Polia"
  },
  {
    "name": "Tríceps barra reta — com pausa",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Polia"
  },
  {
    "name": "Tríceps barra reta — tempo controlado",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Polia"
  },
  {
    "name": "Tríceps barra reta — amplitude completa",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Polia"
  },
  {
    "name": "Tríceps barra reta — unilateral",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Polia"
  },
  {
    "name": "Tríceps barra reta — drop set",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Polia"
  },
  {
    "name": "Tríceps barra V",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Polia"
  },
  {
    "name": "Tríceps barra V — tradicional",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Polia"
  },
  {
    "name": "Tríceps barra V — com pausa",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Polia"
  },
  {
    "name": "Tríceps barra V — tempo controlado",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Polia"
  },
  {
    "name": "Tríceps barra V — amplitude completa",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Polia"
  },
  {
    "name": "Tríceps barra V — unilateral",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Polia"
  },
  {
    "name": "Tríceps barra V — drop set",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Polia"
  },
  {
    "name": "Tríceps testa",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Barra"
  },
  {
    "name": "Tríceps testa — tradicional",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Barra"
  },
  {
    "name": "Tríceps testa — com pausa",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Barra"
  },
  {
    "name": "Tríceps testa — tempo controlado",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Barra"
  },
  {
    "name": "Tríceps testa — amplitude completa",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Barra"
  },
  {
    "name": "Tríceps testa — unilateral",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Barra"
  },
  {
    "name": "Tríceps testa — drop set",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Barra"
  },
  {
    "name": "Tríceps testa com halteres",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Halter"
  },
  {
    "name": "Tríceps testa com halteres — tradicional",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Halter"
  },
  {
    "name": "Tríceps testa com halteres — com pausa",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Halter"
  },
  {
    "name": "Tríceps testa com halteres — tempo controlado",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Halter"
  },
  {
    "name": "Tríceps testa com halteres — amplitude completa",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Halter"
  },
  {
    "name": "Tríceps testa com halteres — unilateral",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Halter"
  },
  {
    "name": "Tríceps testa com halteres — drop set",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Halter"
  },
  {
    "name": "Tríceps francês",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Halter"
  },
  {
    "name": "Tríceps francês — tradicional",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Halter"
  },
  {
    "name": "Tríceps francês — com pausa",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Halter"
  },
  {
    "name": "Tríceps francês — tempo controlado",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Halter"
  },
  {
    "name": "Tríceps francês — amplitude completa",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Halter"
  },
  {
    "name": "Tríceps francês — unilateral",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Halter"
  },
  {
    "name": "Tríceps francês — drop set",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Halter"
  },
  {
    "name": "Tríceps francês na polia",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Polia"
  },
  {
    "name": "Tríceps francês na polia — tradicional",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Polia"
  },
  {
    "name": "Tríceps francês na polia — com pausa",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Polia"
  },
  {
    "name": "Tríceps francês na polia — tempo controlado",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Polia"
  },
  {
    "name": "Tríceps francês na polia — amplitude completa",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Polia"
  },
  {
    "name": "Tríceps francês na polia — unilateral",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Polia"
  },
  {
    "name": "Tríceps francês na polia — drop set",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Polia"
  },
  {
    "name": "Tríceps coice",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Halter"
  },
  {
    "name": "Tríceps coice — tradicional",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Halter"
  },
  {
    "name": "Tríceps coice — com pausa",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Halter"
  },
  {
    "name": "Tríceps coice — tempo controlado",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Halter"
  },
  {
    "name": "Tríceps coice — amplitude completa",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Halter"
  },
  {
    "name": "Tríceps coice — unilateral",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Halter"
  },
  {
    "name": "Tríceps coice — drop set",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Halter"
  },
  {
    "name": "Tríceps coice na polia",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Polia"
  },
  {
    "name": "Tríceps coice na polia — tradicional",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Polia"
  },
  {
    "name": "Tríceps coice na polia — com pausa",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Polia"
  },
  {
    "name": "Tríceps coice na polia — tempo controlado",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Polia"
  },
  {
    "name": "Tríceps coice na polia — amplitude completa",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Polia"
  },
  {
    "name": "Tríceps coice na polia — unilateral",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Polia"
  },
  {
    "name": "Tríceps coice na polia — drop set",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Polia"
  },
  {
    "name": "Mergulho nas paralelas",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Mergulho nas paralelas — tradicional",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Mergulho nas paralelas — com pausa",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Mergulho nas paralelas — tempo controlado",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Mergulho nas paralelas — amplitude completa",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Mergulho nas paralelas — unilateral",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Mergulho nas paralelas — drop set",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Mergulho no banco",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Mergulho no banco — tradicional",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Mergulho no banco — com pausa",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Mergulho no banco — tempo controlado",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Mergulho no banco — amplitude completa",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Mergulho no banco — unilateral",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Mergulho no banco — drop set",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Supino fechado",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Barra"
  },
  {
    "name": "Supino fechado — tradicional",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Barra"
  },
  {
    "name": "Supino fechado — com pausa",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Barra"
  },
  {
    "name": "Supino fechado — tempo controlado",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Barra"
  },
  {
    "name": "Supino fechado — amplitude completa",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Barra"
  },
  {
    "name": "Supino fechado — unilateral",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Barra"
  },
  {
    "name": "Supino fechado — drop set",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Barra"
  },
  {
    "name": "Extensão acima da cabeça",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Elástico"
  },
  {
    "name": "Extensão acima da cabeça — tradicional",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Elástico"
  },
  {
    "name": "Extensão acima da cabeça — com pausa",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Elástico"
  },
  {
    "name": "Extensão acima da cabeça — tempo controlado",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Elástico"
  },
  {
    "name": "Extensão acima da cabeça — amplitude completa",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Elástico"
  },
  {
    "name": "Extensão acima da cabeça — unilateral",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Elástico"
  },
  {
    "name": "Extensão acima da cabeça — drop set",
    "category": "Tríceps",
    "muscleGroup": "Tríceps",
    "equipment": "Elástico"
  },
  {
    "name": "Abdominal supra",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Abdominal supra — tradicional",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Abdominal supra — com pausa",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Abdominal supra — tempo controlado",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Abdominal supra — amplitude completa",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Abdominal supra — unilateral",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Abdominal supra — drop set",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Abdominal infra",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Abdominal infra — tradicional",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Abdominal infra — com pausa",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Abdominal infra — tempo controlado",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Abdominal infra — amplitude completa",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Abdominal infra — unilateral",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Abdominal infra — drop set",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Abdominal canivete",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Abdominal canivete — tradicional",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Abdominal canivete — com pausa",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Abdominal canivete — tempo controlado",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Abdominal canivete — amplitude completa",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Abdominal canivete — unilateral",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Abdominal canivete — drop set",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Abdominal na máquina",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Máquina"
  },
  {
    "name": "Abdominal na máquina — tradicional",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Máquina"
  },
  {
    "name": "Abdominal na máquina — com pausa",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Máquina"
  },
  {
    "name": "Abdominal na máquina — tempo controlado",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Máquina"
  },
  {
    "name": "Abdominal na máquina — amplitude completa",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Máquina"
  },
  {
    "name": "Abdominal na máquina — unilateral",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Máquina"
  },
  {
    "name": "Abdominal na máquina — drop set",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Máquina"
  },
  {
    "name": "Abdominal na polia",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Polia"
  },
  {
    "name": "Abdominal na polia — tradicional",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Polia"
  },
  {
    "name": "Abdominal na polia — com pausa",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Polia"
  },
  {
    "name": "Abdominal na polia — tempo controlado",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Polia"
  },
  {
    "name": "Abdominal na polia — amplitude completa",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Polia"
  },
  {
    "name": "Abdominal na polia — unilateral",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Polia"
  },
  {
    "name": "Abdominal na polia — drop set",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Polia"
  },
  {
    "name": "Abdominal com roda",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Roda abdominal"
  },
  {
    "name": "Abdominal com roda — tradicional",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Roda abdominal"
  },
  {
    "name": "Abdominal com roda — com pausa",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Roda abdominal"
  },
  {
    "name": "Abdominal com roda — tempo controlado",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Roda abdominal"
  },
  {
    "name": "Abdominal com roda — amplitude completa",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Roda abdominal"
  },
  {
    "name": "Abdominal com roda — unilateral",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Roda abdominal"
  },
  {
    "name": "Abdominal com roda — drop set",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Roda abdominal"
  },
  {
    "name": "Prancha",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Prancha — tradicional",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Prancha — com pausa",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Prancha — tempo controlado",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Prancha — amplitude completa",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Prancha — unilateral",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Prancha — drop set",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Prancha lateral",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Prancha lateral — tradicional",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Prancha lateral — com pausa",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Prancha lateral — tempo controlado",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Prancha lateral — amplitude completa",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Prancha lateral — unilateral",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Prancha lateral — drop set",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Prancha com toque no ombro",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Prancha com toque no ombro — tradicional",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Prancha com toque no ombro — com pausa",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Prancha com toque no ombro — tempo controlado",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Prancha com toque no ombro — amplitude completa",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Prancha com toque no ombro — unilateral",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Prancha com toque no ombro — drop set",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Elevação de pernas",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Elevação de pernas — tradicional",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Elevação de pernas — com pausa",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Elevação de pernas — tempo controlado",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Elevação de pernas — amplitude completa",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Elevação de pernas — unilateral",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Elevação de pernas — drop set",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Elevação de joelhos",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Elevação de joelhos — tradicional",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Elevação de joelhos — com pausa",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Elevação de joelhos — tempo controlado",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Elevação de joelhos — amplitude completa",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Elevação de joelhos — unilateral",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Elevação de joelhos — drop set",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Russian twist",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Anilha"
  },
  {
    "name": "Russian twist — tradicional",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Anilha"
  },
  {
    "name": "Russian twist — com pausa",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Anilha"
  },
  {
    "name": "Russian twist — tempo controlado",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Anilha"
  },
  {
    "name": "Russian twist — amplitude completa",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Anilha"
  },
  {
    "name": "Russian twist — unilateral",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Anilha"
  },
  {
    "name": "Russian twist — drop set",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Anilha"
  },
  {
    "name": "Dead bug",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Dead bug — tradicional",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Dead bug — com pausa",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Dead bug — tempo controlado",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Dead bug — amplitude completa",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Dead bug — unilateral",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Dead bug — drop set",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Bird dog",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Bird dog — tradicional",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Bird dog — com pausa",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Bird dog — tempo controlado",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Bird dog — amplitude completa",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Bird dog — unilateral",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Bird dog — drop set",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Pallof press",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Polia"
  },
  {
    "name": "Pallof press — tradicional",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Polia"
  },
  {
    "name": "Pallof press — com pausa",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Polia"
  },
  {
    "name": "Pallof press — tempo controlado",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Polia"
  },
  {
    "name": "Pallof press — amplitude completa",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Polia"
  },
  {
    "name": "Pallof press — unilateral",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Polia"
  },
  {
    "name": "Pallof press — drop set",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Polia"
  },
  {
    "name": "Wood chop",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Polia"
  },
  {
    "name": "Wood chop — tradicional",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Polia"
  },
  {
    "name": "Wood chop — com pausa",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Polia"
  },
  {
    "name": "Wood chop — tempo controlado",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Polia"
  },
  {
    "name": "Wood chop — amplitude completa",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Polia"
  },
  {
    "name": "Wood chop — unilateral",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Polia"
  },
  {
    "name": "Wood chop — drop set",
    "category": "Core",
    "muscleGroup": "Core",
    "equipment": "Polia"
  },
  {
    "name": "Panturrilha em pé",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Máquina"
  },
  {
    "name": "Panturrilha em pé — tradicional",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Máquina"
  },
  {
    "name": "Panturrilha em pé — com pausa",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Máquina"
  },
  {
    "name": "Panturrilha em pé — tempo controlado",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Máquina"
  },
  {
    "name": "Panturrilha em pé — amplitude completa",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Máquina"
  },
  {
    "name": "Panturrilha em pé — unilateral",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Máquina"
  },
  {
    "name": "Panturrilha em pé — drop set",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Máquina"
  },
  {
    "name": "Panturrilha sentada",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Máquina"
  },
  {
    "name": "Panturrilha sentada — tradicional",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Máquina"
  },
  {
    "name": "Panturrilha sentada — com pausa",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Máquina"
  },
  {
    "name": "Panturrilha sentada — tempo controlado",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Máquina"
  },
  {
    "name": "Panturrilha sentada — amplitude completa",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Máquina"
  },
  {
    "name": "Panturrilha sentada — unilateral",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Máquina"
  },
  {
    "name": "Panturrilha sentada — drop set",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Máquina"
  },
  {
    "name": "Panturrilha no leg press",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Máquina"
  },
  {
    "name": "Panturrilha no leg press — tradicional",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Máquina"
  },
  {
    "name": "Panturrilha no leg press — com pausa",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Máquina"
  },
  {
    "name": "Panturrilha no leg press — tempo controlado",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Máquina"
  },
  {
    "name": "Panturrilha no leg press — amplitude completa",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Máquina"
  },
  {
    "name": "Panturrilha no leg press — unilateral",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Máquina"
  },
  {
    "name": "Panturrilha no leg press — drop set",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Máquina"
  },
  {
    "name": "Panturrilha unilateral",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Halter"
  },
  {
    "name": "Panturrilha unilateral — tradicional",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Halter"
  },
  {
    "name": "Panturrilha unilateral — com pausa",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Halter"
  },
  {
    "name": "Panturrilha unilateral — tempo controlado",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Halter"
  },
  {
    "name": "Panturrilha unilateral — amplitude completa",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Halter"
  },
  {
    "name": "Panturrilha unilateral — unilateral",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Halter"
  },
  {
    "name": "Panturrilha unilateral — drop set",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Halter"
  },
  {
    "name": "Panturrilha no Smith",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Máquina"
  },
  {
    "name": "Panturrilha no Smith — tradicional",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Máquina"
  },
  {
    "name": "Panturrilha no Smith — com pausa",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Máquina"
  },
  {
    "name": "Panturrilha no Smith — tempo controlado",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Máquina"
  },
  {
    "name": "Panturrilha no Smith — amplitude completa",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Máquina"
  },
  {
    "name": "Panturrilha no Smith — unilateral",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Máquina"
  },
  {
    "name": "Panturrilha no Smith — drop set",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Máquina"
  },
  {
    "name": "Panturrilha com peso do corpo",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Panturrilha com peso do corpo — tradicional",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Panturrilha com peso do corpo — com pausa",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Panturrilha com peso do corpo — tempo controlado",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Panturrilha com peso do corpo — amplitude completa",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Panturrilha com peso do corpo — unilateral",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Panturrilha com peso do corpo — drop set",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Tibial anterior",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Tibial anterior — tradicional",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Tibial anterior — com pausa",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Tibial anterior — tempo controlado",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Tibial anterior — amplitude completa",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Tibial anterior — unilateral",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Tibial anterior — drop set",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Peso do corpo"
  },
  {
    "name": "Tibial na máquina",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Máquina"
  },
  {
    "name": "Tibial na máquina — tradicional",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Máquina"
  },
  {
    "name": "Tibial na máquina — com pausa",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Máquina"
  },
  {
    "name": "Tibial na máquina — tempo controlado",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Máquina"
  },
  {
    "name": "Tibial na máquina — amplitude completa",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Máquina"
  },
  {
    "name": "Tibial na máquina — unilateral",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Máquina"
  },
  {
    "name": "Tibial na máquina — drop set",
    "category": "Panturrilhas",
    "muscleGroup": "Panturrilhas",
    "equipment": "Máquina"
  },
  {
    "name": "Esteira caminhada",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Esteira"
  },
  {
    "name": "Esteira caminhada — tradicional",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Esteira"
  },
  {
    "name": "Esteira caminhada — com pausa",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Esteira"
  },
  {
    "name": "Esteira caminhada — tempo controlado",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Esteira"
  },
  {
    "name": "Esteira caminhada — amplitude completa",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Esteira"
  },
  {
    "name": "Esteira caminhada — unilateral",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Esteira"
  },
  {
    "name": "Esteira caminhada — drop set",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Esteira"
  },
  {
    "name": "Esteira corrida",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Esteira"
  },
  {
    "name": "Esteira corrida — tradicional",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Esteira"
  },
  {
    "name": "Esteira corrida — com pausa",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Esteira"
  },
  {
    "name": "Esteira corrida — tempo controlado",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Esteira"
  },
  {
    "name": "Esteira corrida — amplitude completa",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Esteira"
  },
  {
    "name": "Esteira corrida — unilateral",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Esteira"
  },
  {
    "name": "Esteira corrida — drop set",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Esteira"
  },
  {
    "name": "Bicicleta ergométrica",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Bicicleta"
  },
  {
    "name": "Bicicleta ergométrica — tradicional",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Bicicleta"
  },
  {
    "name": "Bicicleta ergométrica — com pausa",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Bicicleta"
  },
  {
    "name": "Bicicleta ergométrica — tempo controlado",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Bicicleta"
  },
  {
    "name": "Bicicleta ergométrica — amplitude completa",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Bicicleta"
  },
  {
    "name": "Bicicleta ergométrica — unilateral",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Bicicleta"
  },
  {
    "name": "Bicicleta ergométrica — drop set",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Bicicleta"
  },
  {
    "name": "Bike de spinning",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Bicicleta"
  },
  {
    "name": "Bike de spinning — tradicional",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Bicicleta"
  },
  {
    "name": "Bike de spinning — com pausa",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Bicicleta"
  },
  {
    "name": "Bike de spinning — tempo controlado",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Bicicleta"
  },
  {
    "name": "Bike de spinning — amplitude completa",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Bicicleta"
  },
  {
    "name": "Bike de spinning — unilateral",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Bicicleta"
  },
  {
    "name": "Bike de spinning — drop set",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Bicicleta"
  },
  {
    "name": "Elíptico",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Elíptico"
  },
  {
    "name": "Elíptico — tradicional",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Elíptico"
  },
  {
    "name": "Elíptico — com pausa",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Elíptico"
  },
  {
    "name": "Elíptico — tempo controlado",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Elíptico"
  },
  {
    "name": "Elíptico — amplitude completa",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Elíptico"
  },
  {
    "name": "Elíptico — unilateral",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Elíptico"
  },
  {
    "name": "Elíptico — drop set",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Elíptico"
  },
  {
    "name": "Escada",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Escada"
  },
  {
    "name": "Escada — tradicional",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Escada"
  },
  {
    "name": "Escada — com pausa",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Escada"
  },
  {
    "name": "Escada — tempo controlado",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Escada"
  },
  {
    "name": "Escada — amplitude completa",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Escada"
  },
  {
    "name": "Escada — unilateral",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Escada"
  },
  {
    "name": "Escada — drop set",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Escada"
  },
  {
    "name": "Remo ergométrico",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Remo"
  },
  {
    "name": "Remo ergométrico — tradicional",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Remo"
  },
  {
    "name": "Remo ergométrico — com pausa",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Remo"
  },
  {
    "name": "Remo ergométrico — tempo controlado",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Remo"
  },
  {
    "name": "Remo ergométrico — amplitude completa",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Remo"
  },
  {
    "name": "Remo ergométrico — unilateral",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Remo"
  },
  {
    "name": "Remo ergométrico — drop set",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Remo"
  },
  {
    "name": "Transport",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Elíptico"
  },
  {
    "name": "Transport — tradicional",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Elíptico"
  },
  {
    "name": "Transport — com pausa",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Elíptico"
  },
  {
    "name": "Transport — tempo controlado",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Elíptico"
  },
  {
    "name": "Transport — amplitude completa",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Elíptico"
  },
  {
    "name": "Transport — unilateral",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Elíptico"
  },
  {
    "name": "Transport — drop set",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Elíptico"
  },
  {
    "name": "Corda de pular",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Corda"
  },
  {
    "name": "Corda de pular — tradicional",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Corda"
  },
  {
    "name": "Corda de pular — com pausa",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Corda"
  },
  {
    "name": "Corda de pular — tempo controlado",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Corda"
  },
  {
    "name": "Corda de pular — amplitude completa",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Corda"
  },
  {
    "name": "Corda de pular — unilateral",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Corda"
  },
  {
    "name": "Corda de pular — drop set",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Corda"
  },
  {
    "name": "Ski erg",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Máquina"
  },
  {
    "name": "Ski erg — tradicional",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Máquina"
  },
  {
    "name": "Ski erg — com pausa",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Máquina"
  },
  {
    "name": "Ski erg — tempo controlado",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Máquina"
  },
  {
    "name": "Ski erg — amplitude completa",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Máquina"
  },
  {
    "name": "Ski erg — unilateral",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Máquina"
  },
  {
    "name": "Ski erg — drop set",
    "category": "Cardio",
    "muscleGroup": "Cardio",
    "equipment": "Máquina"
  }
];

export const MUSCLE_GROUPS = [
  "Peito",
  "Costas",
  "Pernas",
  "Glúteos",
  "Ombros",
  "Bíceps",
  "Tríceps",
  "Core",
  "Panturrilhas",
  "Cardio"
] as const;

export const EQUIPMENT_CATALOG = [
  "Anilha",
  "Anilhas",
  "Banco",
  "Barra",
  "Bicicleta",
  "Caneleira",
  "Corda",
  "Elástico",
  "Elíptico",
  "Escada",
  "Esteira",
  "Halter",
  "Kettlebell",
  "Máquina",
  "Peso do corpo",
  "Polia",
  "Remo",
  "Roda abdominal",
  "Triângulo"
] as const;

export const EXERCISE_CATALOG_COUNT = EXERCISE_CATALOG.length;

export const EXERCISE_CATALOG_SOURCES = [
  { name: "free-exercise-db", url: "https://github.com/yuhonas/free-exercise-db", license: "Unlicense" },
  { name: "wger exercise data", url: "https://wger.de/", license: "CC BY-SA 3.0" },
] as const;
