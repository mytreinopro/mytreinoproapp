import * as Notifications from "expo-notifications";
import { Platform } from "react-native";

// Local (on-device) notifications only — no server, no Manus backend involved.
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
    shouldShowBanner: true,
    shouldShowList: true,
  }),
});

let didInit = false;

/** Call once (e.g. on app start). Requests permission and sets up the Android channel. */
export async function ensureNotificationPermission() {
  if (Platform.OS === "web") return false;
  if (didInit) return true;
  didInit = true;

  try {
    const current = await Notifications.getPermissionsAsync();
    if (current.status !== "granted") {
      await Notifications.requestPermissionsAsync();
    }
    if (Platform.OS === "android") {
      await Notifications.setNotificationChannelAsync("timer", {
        name: "Cronômetro de descanso",
        importance: Notifications.AndroidImportance.HIGH,
        sound: "default",
        vibrationPattern: [0, 250, 250, 250],
      });
    }
  } catch (error) {
    console.warn("[notifications] failed to set up permissions", error);
  }
  return true;
}

/**
 * Schedules a local notification to fire in `seconds` seconds, exactly when the
 * rest timer should reach zero. Because this is scheduled by the OS (not by a
 * JS setInterval), it still fires on time even if the app is minimized.
 */
export async function scheduleRestEndNotification(seconds: number, exerciseName: string) {
  if (Platform.OS === "web" || seconds <= 0) return null;
  try {
    const id = await Notifications.scheduleNotificationAsync({
      content: {
        title: "Descanso concluído 💪",
        body: `Hora de voltar: ${exerciseName}`,
        sound: "default",
      },
      // Cast: some expo-notifications versions want an explicit `type` field,
      // others infer it from `seconds`. This form works across recent SDKs.
      trigger: {
        seconds,
        channelId: "timer",
        repeats: false,
      } as unknown as Notifications.NotificationTriggerInput,
    });
    return id;
  } catch (error) {
    console.warn("[notifications] failed to schedule", error);
    return null;
  }
}

export async function cancelNotification(id: string | null) {
  if (!id) return;
  try {
    await Notifications.cancelScheduledNotificationAsync(id);
  } catch {
    // already fired or invalid id — safe to ignore
  }
}
