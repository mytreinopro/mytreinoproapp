import AsyncStorage from "@react-native-async-storage/async-storage";

export const EVOLUTION_STORAGE_KEY = "treino-local-evolution-v1";

export type EvolutionRecord = {
  id: string;
  date: string;
  weightKg: number | null;
  measurements: Record<string, number>;
};

export const DEFAULT_MEASUREMENTS = ["Braço", "Peito", "Cintura", "Coxa", "Panturrilha"];

export async function loadEvolution(): Promise<EvolutionRecord[]> {
  const raw = await AsyncStorage.getItem(EVOLUTION_STORAGE_KEY);
  if (!raw) return [];
  try { return JSON.parse(raw) as EvolutionRecord[]; } catch { return []; }
}

export async function saveEvolution(records: EvolutionRecord[]) {
  await AsyncStorage.setItem(EVOLUTION_STORAGE_KEY, JSON.stringify(records));
}
