import type { ExerciseCatalogItem } from "./exercise-catalog";

export const normalizeExerciseSearch = (value: string) =>
  value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLocaleLowerCase().trim();

export function filterExerciseCatalog(
  catalog: ExerciseCatalogItem[],
  query: string,
  muscleGroup?: string,
  limit = 10,
) {
  const normalizedQuery = normalizeExerciseSearch(query);
  const filtered = normalizedQuery.length > 0
    ? catalog.filter((item) => normalizeExerciseSearch(item.name).includes(normalizedQuery))
    : catalog.filter((item) => !muscleGroup || item.muscleGroup === muscleGroup);
  return filtered.slice(0, limit);
}

export function resolveExerciseMetadata(
  catalog: ExerciseCatalogItem[],
  name: string,
  selectedMuscleGroup: string,
  selectedEquipment: string,
) {
  const exact = catalog.find((item) => normalizeExerciseSearch(item.name) === normalizeExerciseSearch(name));
  return {
    muscleGroup: exact?.muscleGroup ?? selectedMuscleGroup,
    // The user's explicit equipment choice always wins over catalog defaults.
    equipment: selectedEquipment,
  };
}
