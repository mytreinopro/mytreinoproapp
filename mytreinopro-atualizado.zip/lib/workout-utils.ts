export function formatTime(seconds: number) {
  const safeSeconds = Math.max(0, Math.floor(seconds));
  return `${Math.floor(safeSeconds / 60).toString().padStart(2, "0")}:${(safeSeconds % 60).toString().padStart(2, "0")}`;
}

export function calculateEstimatedMinutes(sets: number, restSeconds: number) {
  return Math.max(1, Math.round((Math.max(0, sets) * Math.max(0, restSeconds)) / 60));
}
