import { useEffect, useMemo, useState } from "react";
import { Alert, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import Svg, { Circle, Polyline } from "react-native-svg";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { DEFAULT_MEASUREMENTS, EvolutionRecord, loadEvolution, saveEvolution } from "@/lib/evolution";
import { trpc } from "@/lib/trpc";
import { getApiBaseUrl } from "@/constants/oauth";
import { router } from "expo-router";

const uid = () => `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

export default function EvolutionScreen() {
  const colors = useColors();
  const [records, setRecords] = useState<EvolutionRecord[]>([]);
  const [weight, setWeight] = useState("");
  const [measurements, setMeasurements] = useState<Record<string, string>>({});
  const [loaded, setLoaded] = useState(false);
  const cloudEnabled = Boolean(getApiBaseUrl());
  const backupPull = trpc.appBackup.pull.useQuery(undefined, { enabled: cloudEnabled, retry: false });
  const backupPush = trpc.appBackup.pushEvolution.useMutation();

  useEffect(() => { loadEvolution().then((items) => { setRecords(items); setLoaded(true); }); }, []);
  useEffect(() => { if (loaded) { saveEvolution(records); if (cloudEnabled) { const timer = setTimeout(() => backupPush.mutate({ evolution: JSON.stringify(records) }), 700); return () => clearTimeout(timer); } } }, [records, loaded]);
  useEffect(() => { if (backupPull.data?.payload) { try { const cloud = JSON.parse(backupPull.data.payload); if (Array.isArray(cloud.evolution)) { setRecords(cloud.evolution); setLoaded(true); } } catch { /* keep local data */ } } }, [backupPull.data]);

  const addRecord = () => {
    const parsedWeight = Number(weight.replace(",", "."));
    const parsedMeasurements = Object.fromEntries(Object.entries(measurements).map(([key, value]) => [key, Number(value.replace(",", "."))] as const).filter(([, value]) => Number.isFinite(value) && value > 0));
    if ((!Number.isFinite(parsedWeight) || parsedWeight <= 0) && Object.keys(parsedMeasurements).length === 0) {
      Alert.alert("Registro incompleto", "Informe seu peso ou pelo menos uma medida.");
      return;
    }
    setRecords((current) => [...current, { id: uid(), date: new Date().toISOString(), weightKg: Number.isFinite(parsedWeight) && parsedWeight > 0 ? parsedWeight : null, measurements: parsedMeasurements }]);
    setWeight(""); setMeasurements({});
  };

  const metrics = useMemo(() => {
    const names = new Set<string>(["Peso"]);
    records.forEach((record) => Object.keys(record.measurements).forEach((name) => names.add(name)));
    return Array.from(names);
  }, [records]);

  return <ScreenContainer className="px-5" containerClassName="bg-background">
    <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}><Pressable onPress={() => router.replace("/")} style={styles.backButton}><Text style={[styles.backText, { color: colors.primary }]}>‹ Voltar</Text></Pressable>
      <Text style={[styles.eyebrow, { color: colors.primary }]}>PROGRESSO</Text>
      <Text style={[styles.title, { color: colors.foreground }]}>Sua evolução</Text>
      <Text style={[styles.subtitle, { color: colors.muted }]}>Registre uma vez por mês e acompanhe a tendência real do seu corpo.</Text>
      <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
        <Text style={[styles.cardTitle, { color: colors.foreground }]}>Novo registro · {new Date().toLocaleDateString("pt-BR")}</Text>
        <Text style={[styles.label, { color: colors.muted }]}>PESO (KG)</Text>
        <TextInput value={weight} onChangeText={setWeight} keyboardType="decimal-pad" placeholder="Ex.: 78,5" placeholderTextColor={colors.muted} style={[styles.input, { color: colors.foreground, borderColor: colors.border }]} />
        <Text style={[styles.label, { color: colors.muted }]}>MEDIDAS (CM)</Text>
        <View style={styles.grid}>{DEFAULT_MEASUREMENTS.map((name) => <View key={name} style={styles.metricInput}><Text style={[styles.smallLabel, { color: colors.muted }]}>{name}</Text><TextInput value={measurements[name] ?? ""} onChangeText={(value) => setMeasurements((current) => ({ ...current, [name]: value }))} keyboardType="decimal-pad" placeholder="—" placeholderTextColor={colors.muted} style={[styles.input, { color: colors.foreground, borderColor: colors.border }]} /></View>)}</View>
        <Pressable onPress={addRecord} style={[styles.primaryButton, { backgroundColor: colors.primary }]}><Text style={styles.primaryText}>Salvar registro</Text></Pressable>
      </View>
      {metrics.map((metric) => <MetricChart key={metric} metric={metric} records={records} colors={colors} />)}
      {records.length === 0 && <Text style={[styles.empty, { color: colors.muted }]}>Ainda não há registros. Seu primeiro ponto aparecerá aqui.</Text>}
    </ScrollView>
  </ScreenContainer>;
}

function MetricChart({ metric, records, colors }: { metric: string; records: EvolutionRecord[]; colors: any }) {
  const points = records.map((record) => ({ date: new Date(record.date).toLocaleDateString("pt-BR", { month: "short", year: "2-digit" }), value: metric === "Peso" ? record.weightKg : record.measurements[metric] })).filter((point): point is { date: string; value: number } => typeof point.value === "number" && Number.isFinite(point.value));
  if (!points.length) return null;
  const values = points.map((point) => point.value); const min = Math.min(...values); const max = Math.max(...values); const range = Math.max(1, max - min);
  const width = 300; const height = 120; const coords = points.map((point, index) => ({ x: points.length === 1 ? width / 2 : (index / (points.length - 1)) * (width - 24) + 12, y: height - 20 - ((point.value - min) / range) * (height - 38) }));
  return <View style={[styles.chartCard, { backgroundColor: colors.surface, borderColor: colors.border }]}><Text style={[styles.cardTitle, { color: colors.foreground }]}>{metric}</Text><Svg width="100%" height={height} viewBox={`0 0 ${width} ${height}`}><Polyline points={coords.map((point) => `${point.x},${point.y}`).join(" ")} fill="none" stroke={colors.primary} strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />{coords.map((point, index) => <Circle key={index} cx={point.x} cy={point.y} r="5" fill={colors.primary} />)}</Svg><View style={styles.dateRow}>{points.map((point, index) => <Text key={`${point.date}-${index}`} style={[styles.pointDate, { color: colors.muted }]}>{point.date} · {point.value}</Text>)}</View></View>;
}

const styles = StyleSheet.create({ backButton: { alignSelf: "flex-start", paddingVertical: 6, paddingHorizontal: 2 }, backText: { fontSize: 16, fontWeight: "800" }, content: { paddingTop: 24, paddingBottom: 32, gap: 14 }, eyebrow: { fontSize: 12, fontWeight: "900", letterSpacing: 1.5 }, title: { fontSize: 32, fontWeight: "900" }, subtitle: { fontSize: 15, lineHeight: 22 }, card: { borderWidth: 1, borderRadius: 20, padding: 16, gap: 10 }, chartCard: { borderWidth: 1, borderRadius: 20, padding: 16, gap: 12 }, cardTitle: { fontSize: 16, fontWeight: "800" }, label: { fontSize: 10, fontWeight: "900", letterSpacing: 1 }, smallLabel: { fontSize: 11, fontWeight: "700" }, input: { borderWidth: 1, borderRadius: 12, paddingHorizontal: 12, paddingVertical: 10, fontSize: 16 }, grid: { flexDirection: "row", flexWrap: "wrap", gap: 8 }, metricInput: { width: "48%", gap: 5 }, primaryButton: { borderRadius: 13, paddingVertical: 13, alignItems: "center", marginTop: 4 }, primaryText: { color: "#FFF", fontWeight: "900" }, dateRow: { flexDirection: "row", flexWrap: "wrap", gap: 8 }, pointDate: { fontSize: 9 }, empty: { textAlign: "center", paddingVertical: 28 } });
