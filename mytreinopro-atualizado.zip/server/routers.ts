import { COOKIE_NAME } from "../shared/const.js";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { protectedProcedure } from "./_core/trpc";
import { getUserAppBackup, upsertUserAppBackup } from "./db";
import { z } from "zod";

export const appRouter = router({
  // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),
  appBackup: router({
    pull: protectedProcedure.query(async ({ ctx }) => {
      const backup = await getUserAppBackup(ctx.user.openId);
      return backup ? { payload: backup.payload, updatedAt: backup.updatedAt.toISOString() } : null;
    }),
    push: protectedProcedure.input(z.object({ payload: z.string().max(2_000_000) })).mutation(async ({ ctx, input }) => {
      await upsertUserAppBackup(ctx.user.openId, input.payload);
      return { ok: true, updatedAt: new Date().toISOString() };
    }),
    pushWorkouts: protectedProcedure.input(z.object({ workouts: z.string().max(1_500_000) })).mutation(async ({ ctx, input }) => {
      const current = await getUserAppBackup(ctx.user.openId);
      const previous = current ? JSON.parse(current.payload) : {};
      await upsertUserAppBackup(ctx.user.openId, JSON.stringify({ ...previous, workouts: JSON.parse(input.workouts) }));
      return { ok: true };
    }),
    pushEvolution: protectedProcedure.input(z.object({ evolution: z.string().max(500_000) })).mutation(async ({ ctx, input }) => {
      const current = await getUserAppBackup(ctx.user.openId);
      const previous = current ? JSON.parse(current.payload) : {};
      await upsertUserAppBackup(ctx.user.openId, JSON.stringify({ ...previous, evolution: JSON.parse(input.evolution) }));
      return { ok: true };
    }),
  }),

  // TODO: add feature routers here, e.g.
  // todo: router({
  //   list: protectedProcedure.query(({ ctx }) =>
  //     db.getUserTodos(ctx.user.id)
  //   ),
  // }),
});

export type AppRouter = typeof appRouter;
