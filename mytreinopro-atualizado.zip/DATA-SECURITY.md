# Dados e backup do MyTreinoPRO

## Armazenamento atual

Os treinos e os registros de evolução são mantidos localmente no dispositivo usando `@react-native-async-storage/async-storage`. Os treinos usam a chave `treino-local-workouts-v1` e a evolução usa `treino-local-evolution-v1`. Esse armazenamento não é um banco de dados remoto: apagar os dados do app, desinstalar o aplicativo ou perder o dispositivo pode apagar o histórico local.

O catálogo de exercícios é código estático do aplicativo e não contém dados pessoais.

## Sincronização privada implementada

O projeto agora inclui procedimentos autenticados `appBackup.pull`, `appBackup.pushWorkouts` e `appBackup.pushEvolution`. O backup é vinculado ao `openId` da conta autenticada, não é público e reúne os treinos e a evolução em uma tabela `user_app_backups` no banco do backend. A sincronização é local-first: o app continua funcionando offline e envia alterações automaticamente quando há backend configurado e sessão autenticada.

O payload contém somente dados funcionais do app, como exercícios, séries, carga, dias, peso corporal e medidas. Não há token de GitHub embutido no aplicativo, e dados pessoais não são enviados para commits ou arquivos do repositório.

## Configuração necessária

Para ativar o backup em uma instalação publicada, o backend precisa ter `DATABASE_URL` configurada, a migração da tabela precisa ser aplicada com `pnpm db:push`, e o app precisa receber `EXPO_PUBLIC_API_BASE_URL` apontando para esse backend. Sem essas três condições, o comportamento permanece local-only e o app deve informar isso na documentação/configuração de implantação; não há falsa indicação de que existe backup remoto.

O commit e push solicitados para o código são apenas backup do projeto-fonte. Eles não substituem a sincronização privada dos dados pessoais do usuário.
