# Design do app Treino Local

## Direção do produto

O Treino Local será um app pessoal, direto e sem distrações para montar e executar treinos de musculação. A experiência deve priorizar uso com uma mão, leitura rápida durante o exercício e ações grandes o suficiente para serem tocadas entre séries. Não haverá login, anúncios ou dependência de internet; os dados serão mantidos localmente no aparelho.

## Orientação visual

A interface seguirá uma linguagem próxima de apps nativos de iOS: fundo claro quente, cartões com cantos arredondados, hierarquia tipográfica forte, navegação inferior simples e folhas modais para criação e edição. O tom visual será energético, mas maduro, usando azul-petróleo como cor de ação e laranja queimado para indicar esforço e tempo ativo.

| Elemento | Decisão |
|---|---|
| Cor primária | `#0F766E` — teal profundo para ações principais e estados ativos |
| Cor de destaque | `#F97316` — laranja para timer, progresso e chamadas de atenção |
| Fundo | `#F7F8F6` — branco esverdeado de baixa intensidade |
| Superfície | `#FFFFFF` — cartões e folhas elevadas |
| Texto principal | `#17211F` — quase preto esverdeado |
| Texto secundário | `#6B7773` — descrições e metadados |
| Bordas | `#E1E8E5` — divisórias discretas |
| Sucesso | `#16A34A` — série concluída e treino finalizado |

## Lista de telas

### 1. Início — Meus treinos

A tela inicial apresenta o título “Meus treinos”, uma frase curta de orientação e uma lista dos treinos criados pelo usuário. Cada cartão mostra nome, quantidade de exercícios e duração estimada, com uma ação evidente para iniciar. Um estado vazio explica que o primeiro treino pode ser criado em poucos passos e oferece o botão “Criar treino”.

### 2. Criar/editar treino

Tela ou folha modal para informar o nome do treino e adicionar exercícios. O usuário pode incluir exercícios livres, definir séries, repetições, descanso e carga inicial. A ordem dos exercícios deve ser visível e permitir exclusão e edição sem perder os dados. O botão fixo “Salvar treino” conclui o fluxo.

### 3. Detalhe do treino

Exibe o nome do treino, resumo de duração e a sequência completa de exercícios. Cada exercício mostra séries, repetições, carga registrada e descanso. A tela oferece “Iniciar treino” como ação primária, além de editar e excluir como ações secundárias.

### 4. Execução do treino

Tela focada, com o exercício atual em destaque, contador da série atual, campos ou controles para carga e repetições realizadas, e timer de descanso grande. O usuário consegue marcar uma série como concluída, iniciar/pausar/zerar o descanso e avançar para o próximo exercício. A tela deve impedir que o timer seja confundido com o contador total do treino.

### 5. Treino concluído

Resumo simples após a última série: nome do treino, quantidade de séries concluídas, duração da sessão e confirmação de que os últimos valores de carga foram salvos localmente. O usuário pode voltar para Início ou repetir o treino.

## Modelos de dados

Cada `Workout` terá `id`, `name`, `createdAt`, `updatedAt` e uma lista ordenada de `Exercise`. Cada `Exercise` terá `id`, `name`, `sets`, `reps`, `restSeconds` e `loadKg`. Durante a execução, uma sessão temporária manterá `currentExerciseIndex`, `currentSet`, `startedAt`, `completedSets` e os valores realizados. O estado persistido será serializado em uma chave única do AsyncStorage.

## Fluxos principais

### Criar um treino

1. O usuário toca em “Criar treino”.
2. Informa o nome do treino.
3. Toca em “Adicionar exercício” e preenche nome, séries, repetições, descanso e carga.
4. Repete a ação para incluir outros exercícios.
5. Toca em “Salvar treino” e retorna para a lista inicial.

### Editar carga ou exercício

1. O usuário abre um treino salvo.
2. Toca em “Editar”.
3. Seleciona o exercício desejado.
4. Atualiza a carga, repetições, séries ou descanso.
5. Salva e retorna ao detalhe com os dados atualizados.

### Executar um treino

1. O usuário abre o detalhe e toca em “Iniciar treino”.
2. O app mostra o primeiro exercício e a primeira série.
3. O usuário registra carga/repetições e toca em “Concluir série”.
4. O descanso começa com o tempo configurado; o usuário pode pausar ou avançar.
5. Ao finalizar as séries, o app avança para o próximo exercício.
6. Ao concluir tudo, exibe o resumo e persiste as últimas cargas do treino.

## Princípios de interação

Os botões primários terão altura confortável, feedback visual ao toque e, quando possível, retorno tátil leve. O timer usará números grandes, cor de destaque e controles sempre visíveis. Exclusões exigirão confirmação. Listas longas usarão `FlatList`, e todas as telas respeitarão áreas seguras do aparelho e o espaço da barra inferior.
