# Fontes verificadas

- Expo SDK 57 / Expo Go: https://expo.dev/go
- Expo Router migration: https://docs.expo.dev/router/migrate/sdk-55-to-56/
- free-exercise-db: https://github.com/yuhonas/free-exercise-db — repository describes 800+ exercises and uses the Unlicense.
- wger documentation: https://wger.readthedocs.io/en/2.0/ — documentation states initial exercise and ingredient data are licensed CC BY-SA 3.0; application code is AGPL 3+.

Use only compatible public/open data and preserve attribution where applicable. The current MyTreinoPRO catalog is a separately generated original/curated list with source metadata, not a direct copy of proprietary app data.
