import { describe, expect, it } from "vitest";
import { EQUIPMENT_CATALOG, EXERCISE_CATALOG, MUSCLE_GROUPS } from "../lib/exercise-catalog";
import { filterExerciseCatalog, resolveExerciseMetadata } from "../lib/exercise-utils";

describe("exercise catalog", () => {
  it("contains a broad original catalog", () => {
    expect(EXERCISE_CATALOG.length).toBeGreaterThanOrEqual(500);
    expect(new Set(EXERCISE_CATALOG.map((item) => item.muscleGroup)).size).toBeGreaterThanOrEqual(8);
  });

  it("provides equipment metadata for every exercise", () => {
    expect(EXERCISE_CATALOG.every((item) => item.name && item.muscleGroup && item.equipment)).toBe(true);
    expect(EQUIPMENT_CATALOG).toContain("Peso do corpo");
    expect(MUSCLE_GROUPS).toContain("Peito");
  });

  it("keeps the equipment explicitly selected by the user", () => {
    const metadata = resolveExerciseMetadata(EXERCISE_CATALOG, "Supino reto", "Peito", "Anilhas");
    expect(metadata.muscleGroup).toBe("Peito");
    expect(metadata.equipment).toBe("Anilhas");
  });

  it("filters autocomplete by text across muscle groups and ignores accents", () => {
    const results = filterExerciseCatalog(EXERCISE_CATALOG, "elevacao pelvica", "Peito");
    expect(results.length).toBeGreaterThan(0);
    expect(results.every((item) => item.name.toLocaleLowerCase().includes("elevação pélvica") || item.name.toLocaleLowerCase().includes("elevacao pelvica"))).toBe(true);
  });
});
