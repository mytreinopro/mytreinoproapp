import { describe, expect, it } from "vitest";
import { calculateEstimatedMinutes, formatTime } from "../lib/workout-utils";

describe("workout timer utilities", () => {
  it("formats seconds as MM:SS", () => {
    expect(formatTime(0)).toBe("00:00");
    expect(formatTime(65)).toBe("01:05");
    expect(formatTime(125)).toBe("02:05");
  });

  it("does not allow negative timer values", () => {
    expect(formatTime(-10)).toBe("00:00");
  });

  it("calculates an estimated duration with a one-minute minimum", () => {
    expect(calculateEstimatedMinutes(3, 60)).toBe(3);
    expect(calculateEstimatedMinutes(0, 0)).toBe(1);
  });
});
