# Project TODO

- [x] Identidade visual e ícone personalizado do Treino Local
- [x] Tela inicial com lista de treinos e estado vazio
- [x] Criar e editar treinos personalizados
- [x] Adicionar, editar, reordenar e excluir exercícios
- [x] Configurar séries, repetições, descanso e carga
- [x] Persistir treinos e cargas com AsyncStorage
- [x] Tela de detalhe do treino
- [x] Fluxo de execução do treino
- [x] Timer de descanso com iniciar, pausar, zerar e avançar
- [x] Atualizar e salvar últimas cargas durante a execução
- [x] Tela de treino concluído
- [x] Navegação inferior e ícones do app
- [x] Testes unitários para persistência e timer
- [x] Validar TypeScript, lint e fluxos principais

- [x] Pesquisar uma nova opção de nome e verificar uso público, domínio e sinais de conflito
- [x] Documentar que a pesquisa de nome não substitui consulta jurídica ao INPI
- [x] Gerar e aplicar nova logo ao app
- [x] Levantar catálogo abrangente de exercícios atuais
- [x] Levantar catálogo abrangente de maquinários e equipamentos de academia
- [x] Criar seleção local de exercícios e equipamentos para cadastro rápido
- [x] Atualizar nome, slug visual e configuração de branding do app
- [x] Validar pesquisa, catálogo, identidade visual e testes do app

- [x] Renomear o app visualmente para MyTreinoPRO e atualizar o branding exibido no iPhone

- [x] Renomear o app visualmente para MyTreinoPRO e atualizar o branding exibido no iPhone
- [x] Criar e aplicar uma logo única e premium para MyTreinoPRO
