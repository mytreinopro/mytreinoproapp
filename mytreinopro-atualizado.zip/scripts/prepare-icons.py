from pathlib import Path
from PIL import Image

source = Image.open(Path('/home/ubuntu/webdev-static-assets/carga-nativa-icon.png')).convert('RGBA')
outputs = {
    'assets/images/icon.png': 1024,
    'assets/images/splash-icon.png': 512,
    'assets/images/android-icon-foreground.png': 432,
    'assets/images/favicon.png': 196,
}
for relative_path, size in outputs.items():
    output = source.resize((size, size), Image.Resampling.LANCZOS)
    output.save(Path('/home/ubuntu/treino-local') / relative_path, format='PNG', optimize=True)
