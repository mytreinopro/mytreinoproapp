import { writeFileSync } from "node:fs";

const groups = {
  Peito: [
    ["Supino reto", "Barra"], ["Supino inclinado", "Barra"], ["Supino declinado", "Barra"], ["Supino reto", "Halter"], ["Supino inclinado", "Halter"], ["Supino declinado", "Halter"], ["Supino na máquina", "Máquina"], ["Chest press", "Máquina"], ["Crucifixo reto", "Halter"], ["Crucifixo inclinado", "Halter"], ["Crucifixo na máquina", "Máquina"], ["Crossover alto", "Polia"], ["Crossover médio", "Polia"], ["Crossover baixo", "Polia"], ["Flexão de braço", "Peso do corpo"], ["Flexão inclinada", "Peso do corpo"], ["Flexão declinada", "Peso do corpo"], ["Flexão diamante", "Peso do corpo"], ["Pullover", "Halter"], ["Pullover na polia", "Polia"],
  ],
  Costas: [
    ["Puxada frontal", "Polia"], ["Puxada supinada", "Polia"], ["Puxada neutra", "Polia"], ["Puxada unilateral", "Polia"], ["Barra fixa pronada", "Peso do corpo"], ["Barra fixa supinada", "Peso do corpo"], ["Barra fixa neutra", "Peso do corpo"], ["Remada baixa", "Polia"], ["Remada curvada", "Barra"], ["Remada cavalinho", "Barra"], ["Remada unilateral", "Halter"], ["Remada na máquina", "Máquina"], ["Remada articulada", "Máquina"], ["Remada serrote", "Halter"], ["Pulldown reto", "Polia"], ["Pullover para dorsais", "Polia"], ["Encolhimento", "Halter"], ["Encolhimento com barra", "Barra"], ["Hiperextensão lombar", "Peso do corpo"], ["Good morning", "Barra"],
  ],
  Pernas: [
    ["Agachamento livre", "Barra"], ["Agachamento frontal", "Barra"], ["Agachamento sumô", "Halter"], ["Agachamento goblet", "Kettlebell"], ["Agachamento no Smith", "Máquina"], ["Agachamento hack", "Máquina"], ["Leg press 45°", "Máquina"], ["Leg press horizontal", "Máquina"], ["Cadeira extensora", "Máquina"], ["Cadeira flexora", "Máquina"], ["Mesa flexora", "Máquina"], ["Levantamento terra", "Barra"], ["Terra romeno", "Barra"], ["Terra sumô", "Barra"], ["Stiff", "Barra"], ["Stiff unilateral", "Halter"], ["Afundo", "Halter"], ["Afundo no Smith", "Máquina"], ["Passada", "Halter"], ["Passada reversa", "Halter"], ["Passada caminhando", "Halter"], ["Step-up", "Halter"], ["Step-up", "Peso do corpo"], ["Agachamento búlgaro", "Halter"], ["Cadeira sissy", "Peso do corpo"], ["Flexão nórdica", "Peso do corpo"], ["Extensão de quadril", "Polia"], ["Adutora", "Máquina"], ["Abdutora", "Máquina"], ["Agachamento com elástico", "Elástico"],
  ],
  Glúteos: [
    ["Elevação pélvica", "Barra"], ["Elevação pélvica", "Máquina"], ["Elevação pélvica unilateral", "Peso do corpo"], ["Glúteo no cabo", "Polia"], ["Glúteo na máquina", "Máquina"], ["Coice no cabo", "Polia"], ["Coice com elástico", "Elástico"], ["Abdução de quadril", "Máquina"], ["Abdução de quadril", "Elástico"], ["Extensão de quadril", "Banco"], ["Frog pump", "Peso do corpo"], ["Bom dia", "Barra"],
  ],
  Ombros: [
    ["Desenvolvimento militar", "Barra"], ["Desenvolvimento com halteres", "Halter"], ["Desenvolvimento Arnold", "Halter"], ["Desenvolvimento no Smith", "Máquina"], ["Desenvolvimento na máquina", "Máquina"], ["Elevação lateral", "Halter"], ["Elevação lateral na polia", "Polia"], ["Elevação lateral na máquina", "Máquina"], ["Elevação frontal", "Halter"], ["Elevação frontal com barra", "Barra"], ["Elevação frontal na polia", "Polia"], ["Crucifixo inverso", "Halter"], ["Crucifixo inverso na máquina", "Máquina"], ["Face pull", "Polia"], ["Remada alta", "Barra"], ["Remada alta na polia", "Polia"], ["Rotação externa", "Elástico"], ["Rotação interna", "Elástico"],
  ],
  Bíceps: [
    ["Rosca direta", "Barra"], ["Rosca direta na polia", "Polia"], ["Rosca W", "Barra"], ["Rosca Scott", "Barra"], ["Rosca Scott na máquina", "Máquina"], ["Rosca alternada", "Halter"], ["Rosca simultânea", "Halter"], ["Rosca martelo", "Halter"], ["Rosca martelo na corda", "Polia"], ["Rosca concentrada", "Halter"], ["Rosca inclinada", "Halter"], ["Rosca spider", "Halter"], ["Rosca inversa", "Barra"], ["Rosca drag", "Barra"], ["Rosca 21", "Barra"],
  ],
  Tríceps: [
    ["Tríceps na polia", "Polia"], ["Tríceps na corda", "Polia"], ["Tríceps barra reta", "Polia"], ["Tríceps barra V", "Polia"], ["Tríceps testa", "Barra"], ["Tríceps testa com halteres", "Halter"], ["Tríceps francês", "Halter"], ["Tríceps francês na polia", "Polia"], ["Tríceps coice", "Halter"], ["Tríceps coice na polia", "Polia"], ["Mergulho nas paralelas", "Peso do corpo"], ["Mergulho no banco", "Peso do corpo"], ["Supino fechado", "Barra"], ["Extensão acima da cabeça", "Elástico"],
  ],
  Core: [
    ["Abdominal supra", "Peso do corpo"], ["Abdominal infra", "Peso do corpo"], ["Abdominal canivete", "Peso do corpo"], ["Abdominal na máquina", "Máquina"], ["Abdominal na polia", "Polia"], ["Abdominal com roda", "Roda abdominal"], ["Prancha", "Peso do corpo"], ["Prancha lateral", "Peso do corpo"], ["Prancha com toque no ombro", "Peso do corpo"], ["Elevação de pernas", "Peso do corpo"], ["Elevação de joelhos", "Peso do corpo"], ["Russian twist", "Anilha"], ["Dead bug", "Peso do corpo"], ["Bird dog", "Peso do corpo"], ["Pallof press", "Polia"], ["Wood chop", "Polia"],
  ],
  Panturrilhas: [
    ["Panturrilha em pé", "Máquina"], ["Panturrilha sentada", "Máquina"], ["Panturrilha no leg press", "Máquina"], ["Panturrilha unilateral", "Halter"], ["Panturrilha no Smith", "Máquina"], ["Panturrilha com peso do corpo", "Peso do corpo"], ["Tibial anterior", "Peso do corpo"], ["Tibial na máquina", "Máquina"],
  ],
  Cardio: [
    ["Esteira caminhada", "Esteira"], ["Esteira corrida", "Esteira"], ["Bicicleta ergométrica", "Bicicleta"], ["Bike de spinning", "Bicicleta"], ["Elíptico", "Elíptico"], ["Escada", "Escada"], ["Remo ergométrico", "Remo"], ["Transport", "Elíptico"], ["Corda de pular", "Corda"], ["Ski erg", "Máquina"],
  ],
};

const suffixes = [
  ["tradicional", "Padrão"],
  ["com pausa", "Padrão"],
  ["tempo controlado", "Padrão"],
  ["amplitude completa", "Padrão"],
  ["unilateral", "Padrão"],
  ["drop set", "Padrão"],
];

const rows = [];
for (const [group, items] of Object.entries(groups)) {
  for (const [name, equipment] of items) {
    rows.push({ name, category: group, muscleGroup: group, equipment });
    for (const [suffix, variantEquipment] of suffixes) {
      rows.push({ name: `${name} — ${suffix}`, category: group, muscleGroup: group, equipment: variantEquipment === "Padrão" ? equipment : variantEquipment });
    }
  }
}

const unique = Array.from(new Map(rows.map((item) => [`${item.name}|${item.muscleGroup}|${item.equipment}`, item])).values());
const equipment = Array.from(new Set(unique.map((item) => item.equipment).concat(["Barra", "Halter", "Triângulo", "Polia", "Máquina", "Peso do corpo", "Elástico", "Kettlebell", "Anilhas", "Banco", "Caneleira", "Corda"]))).sort((a, b) => a.localeCompare(b, "pt-BR"));
const groupsList = Object.keys(groups);

const output = `// Base própria do MyTreinoPRO, organizada por grupo muscular e equipamento.\n// Os nomes são descrições genéricas e não foram copiados de uma base proprietária.\nexport type ExerciseCatalogItem = {\n  name: string;\n  category: string;\n  muscleGroup: string;\n  equipment: string;\n};\n\nexport const EXERCISE_CATALOG: ExerciseCatalogItem[] = ${JSON.stringify(unique, null, 2)};\n\nexport const MUSCLE_GROUPS = ${JSON.stringify(groupsList, null, 2)} as const;\n\nexport const EQUIPMENT_CATALOG = ${JSON.stringify(equipment, null, 2)} as const;\n\nexport const EXERCISE_CATALOG_COUNT = EXERCISE_CATALOG.length;\n\nexport const EXERCISE_CATALOG_SOURCES = [\n  { name: "free-exercise-db", url: "https://github.com/yuhonas/free-exercise-db", license: "Unlicense" },\n  { name: "wger exercise data", url: "https://wger.de/", license: "CC BY-SA 3.0" },\n] as const;\n`;

writeFileSync("lib/exercise-catalog.ts", output);
console.log(`Generated ${unique.length} exercises across ${groupsList.length} muscle groups.`);
if (unique.length < 500) process.exit(1);
