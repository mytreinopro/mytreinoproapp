from PIL import Image, ImageChops

source = Image.open('/home/ubuntu/upload/IMG_6917.jpeg').convert('RGB')
# Crop only the green dumbbell/arrow symbol; exclude the wordmark and gym background edges.
crop = source.crop((535, 125, 875, 485))
# Use the app's dark neutral as the clean, consistent background.
canvas = Image.new('RGB', (1024, 1024), '#151718')
crop.thumbnail((820, 820), Image.Resampling.LANCZOS)
canvas.paste(crop, ((1024 - crop.width) // 2, (1024 - crop.height) // 2))
canvas.save('assets/images/mytreinopro-symbol.png', optimize=True)
# Header asset with the same neutral background and transparent-safe square bounds.
canvas.resize((256, 256), Image.Resampling.LANCZOS).save('assets/images/mytreinopro-symbol-small.png', optimize=True)
print('logo assets written')
